const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const BillingAddressModal = require("./app/model/billing_address")
const auth = require('./app/middleware/auth');
const NotificationModal = require("./app/model/notification");


const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);


router.get('/bill-address',auth.isLogin,async function(req,res){
    const billingaddress = await BillingAddressModal.find();
    res.render("./billing_address/index", { billingaddress: billingaddress, data: req.data });                      
});

router.get('/add-billing-address',auth.isLogin, function(req,res){
    res.render("./billing_address/add-billing-address", { data: req.data });                      
});

router.post('/add-billing-address',auth.isLogin, async function(req,res){
        const billing_address = new BillingAddressModal({
        address1: req.body.address1,
        street: req.body.street,
        zipcode: req.body.zipcode,
        city: req.body.city,
        country: req.body.country,
        user: req.body.user,
    });
    
    await billing_address.save().then(data => {
        let message = req.body.address1 + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/categories')
    }).catch(err => {
        res.redirect('/categories')
    });                  
});

router.get('/update-billing-address/:id',auth.isLogin, async function(req,res){
    const billing_address = await BillingAddressModal.findById(req.params.id);
    res.render("./billing_address/update-billing-address", { billing_address: billing_address, data: req.data});                      
});

router.post('/update-billing-address/:id',auth.isLogin, async function(req, res) {
        const id = req.params.id;
    
    await BillingAddressModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/billing-address')
        }else{
            res.redirect('/billing-address')
        }
    }).catch(err => {
        res.redirect('/billing-address')
    });

});

router.get('/delete-billing-address/:id',auth.isLogin, async function(req,res){
    const id = req.params.id;
    await BillingAddressModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/bill-address')
        } else {
            res.redirect('/bill-address')
        }
    }).catch(err => {
        res.redirect('/bill-address')
    });                     
});
 




module.exports = router;


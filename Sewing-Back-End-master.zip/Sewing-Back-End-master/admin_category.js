const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const CategoryModal = require("./app/model/category")
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); 
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);



router.get('/categories',auth.isLogin, async function(req,res){
    const categories =  await CategoryModal.find();
    res.render("./categories/index",{ categories: categories,  data: req.data});                      
});

router.get('/add-category',auth.isLogin, function(req, res){
    res.render("./categories/add-category", {  data: req.data });
});

router.get('/update-category/:id',auth.isLogin, async function(req, res){
    const category = await CategoryModal.findById(req.params.id);
    res.render("./categories/update-category", { category: category,  data: req.data });     
});

router.post('/add-category',auth.isLogin, upload.single('avatar'), async function(req, res)
{
    const category_image = await uploadImage(req.file.path);
    console.log("Image URL ==============>",category_image);
    const category = new CategoryModal({
        title: req.body.title,
        image_url: category_image
    });
    await category.save().then(data => {
        let message = req.body.title + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/categories')
    }).catch(err => {
        console.log(err.message);
        res.redirect('/categories')
});

});


router.post('/update-category/:id',auth.isLogin, async function(req, res) {
    const id = req.params.id;
    
    await CategoryModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
                    console.log("1")
            res.redirect('/categories')
        }else{
                    console.log("2")
            res.redirect('/categories')
        }
    }).catch(err => {
        console.log("something went wrong")
        res.redirect('/categories')
    });

});

router.get('/delete-category/:id',auth.isLogin,  async function(req, res){
    const id = req.params.id;
    await CategoryModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/categories')
        } else {
            res.redirect('/categories')
        }
    }).catch(err => {
        res.redirect('/categories')
    });
});
   
module.exports = router;

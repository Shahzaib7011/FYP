const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const ContactUsModal = require("./app/model/contact_us")
const auth = require('./app/middleware/auth');
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)
    };
    next();
};

router.use(auth.isLogin, setData);


router.get('/admin_contact_us', async function(req,res){
    const contact_us =  await ContactUsModal.find();
    res.render("./contact_us/index",{ contact_us: contact_us, data: req.data});                      
});

router.get('/update-contact_us/:id', async function(req, res){
    const contact_us = await CategoryModal.findById(req.params.id);
    res.render("./categories/update-contact_us", {contact_us: contact_us, data: req.data});     
});


router.post('/update-contact_us/:id', async function(req, res) {
    const id = req.params.id;
    
    await ContactUsModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
                    console.log("1")
            res.redirect('/contact_us', { data: req.data })
        }else{
                    console.log("2")
            res.redirect('/contact_us',{ data: req.data })
        }
    }).catch(err => {
        console.log("something went wrong")
        res.redirect('/contact_us', { data: req.data })
    });

});

module.exports = router;

const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const FaqModal = require("./app/model/faq");
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); 
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)
    };
    next();
};

router.use(auth.isLogin, setData);

router.get('/faqs',auth.isLogin, async function(req,res){
    const faqs =  await FaqModal.find();
    res.render("./faqs/index",{ faqs: faqs,  data: req.data});                      
});

router.get('/add-faqs',auth.isLogin, function(req, res){
    res.render("./faqs/add-faq", {  data: req.data });
});

router.get('/update-faqs/:id',auth.isLogin, async function(req, res){
    const faq = await FaqModal.findById(req.params.id);
    res.render("./faqs/update-faq", { faq: faq,  data: req.data });     
});

router.post('/add-faq',auth.isLogin, upload.single('avatar'), async function(req, res)
{
    // const category_image = await uploadImage(req.file.path);
    // console.log("Image URL ==============>",category_image);
    const faq = new FaqModal({
        answer: req.body.answer,
        question: req.body.question,
        tag_line: req.body.tag_line

    });
    await faq.save().then(data => {
        let message = req.body.question + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/faqs')
    }).catch(err => {
        console.log(err.message);
        res.redirect('/faqs')
});

});


router.post('/update-faqs/:id',auth.isLogin, async function(req, res) {
    const id = req.params.id;

    console.log("THIS ===============>", id);    
    await FaqModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/faqs')
        }else{
            res.redirect('/faqs')
        }
    }).catch(err => {
        res.redirect('/faqs')
    });

});

router.get('/delete-faq/:id',auth.isLogin,  async function(req, res){
    const id = req.params.id;
    await FaqModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/faqs')
        } else {
            res.redirect('/faqs')
        }
    }).catch(err => {
        res.redirect('/faqs')
    });
});
   
module.exports = router;

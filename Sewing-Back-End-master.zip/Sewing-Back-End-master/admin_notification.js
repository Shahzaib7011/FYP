const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const NotificationModal = require("./app/model/notification");
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); 

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)
    };
    next();
};

router.use(auth.isLogin, setData);

router.get('/notifications',auth.isLogin, async function(req,res){
    const notifications =  await NotificationModal.find();
    res.render("./notifications/index",{ notifications: notifications,  data: req.data});                      
});

   
module.exports = router;

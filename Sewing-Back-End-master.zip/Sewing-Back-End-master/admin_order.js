const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const OrderModel = require("./app/model/order");
const LineItemModel = require("./app/model/line_item");
const UserModel = require("./app/model/user");
const BillingAddressModel = require("./app/model/billing_address");
const auth = require('./app/middleware/auth');
const { format } = require('date-fns');
const NotificationModal = require("./app/model/notification");


// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);


router.get('/orders',auth.isLogin, async function(req,res){
    console.log("Request inside the orders page");
    const orders = await OrderModel.find().populate('user', 'shipping_address');
    const pending_state =  orders.filter(order => order.status === 'pending');
    const order_confirmed = await orders.filter(order => order.status === 'order_confirmed');
    const order_delivered = await orders.filter(order => order.status === 'order_delivered');
    res.render("./orders/index", { orders: orders, data: req.data, pending_state: pending_state, order_confirmed: order_confirmed, order_delivered: order_delivered});                      
});

router.get('/orders/:id', async function(req, res) {try {
    const order = await OrderModel.findById(req.params.id);
    const user = await UserModel.findById(order.user);
    const billing_address = await BillingAddressModel.findById(order.billing_address);
    const lineItems = await LineItemModel.find({ order: req.params.id }).populate({
        path: 'product',
        select: 'title'
    });
    if (lineItems.length === 0) {
        return res.status(404).json({ message: 'No line items found for this order.' });
    }
    res.render("./orders/show", {
        lineItems: lineItems, // Pass the entire array of line items
        order: order, 
        user_info: user,// Pass the order object if needed
        billing_address_info: billing_address
        
    });
} catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
}
});



router.get('/delete-order/:id',auth.isLogin ,  async function(req, res){
    const id = req.params.id;
    try {
        await LineItemModel.deleteMany({ order: id });
        await OrderModel.findByIdAndDelete(id);
        res.redirect('/orders')
    } catch (error) {
        res.redirect('/orders')
    }

});

module.exports = router;

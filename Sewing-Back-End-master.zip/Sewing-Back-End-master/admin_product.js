const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const ProductModal = require("./app/model/product")
const CategoryModal = require("./app/model/category")
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const NotificationModal = require("./app/model/notification");
const geoip = require('geoip-lite');

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);



router.get('/products', async function(req,res){
    const products =  await ProductModal.find().populate('category', 'title');
    res.render("./products/index",{ products: products, data: req.data });                      
});

router.get('/add-product', async function(req, res){
    const categories = await CategoryModal.find();
    res.render("./products/add-product",{ categories: categories, data: req.data });
});

router.get('/update-product/:id',auth.isLogin, async function(req, res){
    const product = await ProductModal.findById(req.params.id);
    res.render("./products/update-product", {product: product, data: req.data});     
});

router.post('/add-product', auth.isLogin, upload.single('avatar'), async function(req, res) {
    try {
        const product_image = await uploadImage(req.file.path);
        // Get the client's IP address
        let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        clientIp =  clientIp == '::1' ? '39.49.59.76' : clientIp
        let latitude = '';
        let longitude = '';
        let address = '';
        var geo = geoip.lookup(clientIp);
        if (geo) {
            const city = geo.city;
            const timezone = geo.timezone;
            const country = geo.country;
            const region = geo.region;
            latitude = geo.ll[0];
            latitude = geo.ll[1];
            address =  `${country}, ${region}, ${timezone}`;
          } else {
            console.log('No geo data found for this IP address.');
          }
        const product = new ProductModal({
            title: req.body.title,
            description: req.body.description,
            sale_price: req.body.sale_price,
            list_price: req.body.list_price,
            stock: req.body.stock,
            category: req.body.category,
            image_url: product_image,
            latitude: latitude,
            longitude: longitude,
            address: address
        });

        await product.save().then(data => {
            let message = req.body.title + " is created successfully";
            const newNotification = new NotificationModal({ text: message });
            newNotification.save();
            res.redirect('/products');
        }).catch(err => {
            console.log(err.message);
            res.redirect('/products');
        });

    } catch (err) {
        console.error('Error:', err);
        res.redirect('/products');
    }
});

    
router.post('/update-product/:id',auth.isLogin,async function(req, res){
    if(!req.body) {
        res.redirect('/products')
    }

    const id = req.params.id;
    
    await ProductModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/products')
        }else{
            res.redirect('/products')
        }
    }).catch(err => {
        res.redirect('/products')
    });
});


router.get('/delete-product/:id',auth.isLogin,  async function(req, res){
    const id = req.params.id;
    console.log("Product ID ======>", id);
    await ProductModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/products')
        } else {
            res.redirect('/products')
        }
    }).catch(err => {
        res.redirect('/products')
    });
})


module.exports = router;

const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const RoleModel = require("./app/model/role");
const auth = require('./app/middleware/auth');
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)
    };
    next();
};

router.use(auth.isLogin, setData);

router.get('/roles',auth.isLogin, async function(req,res){
    const roles =  await RoleModel.find();
    res.render("./roles/index",{ roles: roles, data: req.data});                      
});

router.get('/add-roles',auth.isLogin, function(req, res){
    res.render("./roles/add-role", {  data: req.data });
});

router.post('/add-roles',auth.isLogin, async function(req, res)
{
    console.log(req.body);
    const role = new RoleModel({
        title: req.body.title,
    });
    await role.save().then(data => {
        let message =  req.body.title + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/roles');
    }).catch(err => {
        console.log(err.message);
        res.redirect('/roles');
    });
});

router.get('/delete-role/:id',auth.isLogin,  async function(req, res){
    const id = req.params.id;
    await RoleModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/categories')
        } else {
            res.redirect('/categories')
        }
    }).catch(err => {
        res.redirect('/categories')
    });
});

router.get('/update-role/:id',auth.isLogin, async function(req, res){
    const role = await RoleModel.findById(req.params.id);
    res.render("./roles/update-role", { role: role,  data: req.data });     
});


router.post('/update-role/:id',auth.isLogin, async function(req, res) {
    const id = req.params.id;
    
    await RoleModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
                    console.log("1")
            res.redirect('/roles')
        }else{
                    console.log("2")
            res.redirect('/roles')
        }
    }).catch(err => {
        console.log("something went wrong")
        res.redirect('/roles')
    });

});
   


module.exports = router;
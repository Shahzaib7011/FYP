const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const ServiceModal = require("./app/model/service")
const auth = require('./app/middleware/auth');
const NotificationModal = require("./app/model/notification");



// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);



router.get('/services', auth.isLogin,  async function(req,res){
    const services = await ServiceModal.find();
    res.render("./services/index", {services: services, data: req.data});                      
});
  
router.get('/add-services', auth.isLogin, function(req, res){
    res.render("./services/add-services",  { data: req.data });     
});

router.get('/update-services/:id', auth.isLogin, async function(req, res){
    const service = await ServiceModal.findById(req.params.id);
    res.render("./services/update-services", {service: service, data: req.data});     
});
  
router.post('/add-services', auth.isLogin, async function(req, res){
    console.log(req.body)
    const service = new ServiceModal({
        name: req.body.name,
        tag_line: req.body.tag_line,
        item_included_one: req.body.item_included_one,
        item_included_two: req.body.item_included_two,
        item_included_three: req.body.item_included_three,
        tailors_count: req.body.tailors_count,
        premium_support_days: req.body.premium_support_days,
        free_updates_days: req.body.free_updates_days,
        price: req.body.price
    });
    await service.save().then(data => {
        let message =  req.body.name + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        console.log("Data saved")
        res.redirect('/services');
    }).catch(err => {
        console.log(err.message);
          res.redirect('/services');
    });
});


router.post('/update-services/:id', auth.isLogin, async function(req, res){
    if(!req.body) {
     res.redirect('/services');
    }

    const id = req.params.id;
    
    await ServiceModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/services');
        }else{
         res.redirect('/services');
        }
    }).catch(err => {
        res.redirect('/services');
    });
});


router.get('/delete-services/:id', auth.isLogin,  async function(req, res){
    const id = req.params.id;
    await ServiceModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/services');

        } else {
            res.redirect('/services');
        }
    }).catch(err => {
        res.redirect('/services');
    });
});
   

module.exports = router;
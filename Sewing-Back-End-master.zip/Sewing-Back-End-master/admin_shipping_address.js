const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const ShippingAddressModal = require("./app/model/shipping_address")
const auth = require('./app/middleware/auth');
const NotificationModal = require("./app/model/notification");


// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);





router.get('/ship_address',auth.isLogin, async function(req,res){
    const shipping_address = await ShippingAddressModal.find();
    res.render("./ship_address/index", {shipping_address: shipping_address, data: req.data });                      
});

router.get('/add-ship-address',auth.isLogin, function(req,res){
    res.render("./ship_address/add-ship-address", { data: req.data });                      
});

router.post('/add-ship-address',auth.isLogin, async function(req,res){
        const shipping_address = new ShippingAddressModal({
        address1: req.body.address1,
        street: req.body.street,
        zipcode: req.body.zipcode,
        city: req.body.city,
        country: req.body.country,
        user: req.body.user,
    });
    
    await shipping_address.save().then(data => {
        res.redirect('/ship_address', { data: req.data })
    }).catch(err => {
        res.redirect('/ship_address', { data: req.data })
    });                  
});

router.get('/update-ship-address/:id',auth.isLogin, async function(req,res){
    const shipping_address = await ShippingAddressModal.findById(req.params.id);
    res.render("./ship_address/update-ship-address", { shipping_address: shipping_address, data: req.data });                      
});

router.post('/update-ship-address/:id',auth.isLogin,  async function(req, res) {
        const id = req.params.id;
    
    await ShippingAddressModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/ship_address', { data: req.data })
        }else{
            res.redirect('/ship_address', { data: req.data })
        }
    }).catch(err => {
        res.redirect('/ship_address', { data: req.data })
    });

});

router.get('/delete-ship-address/:id',auth.isLogin,async function(req,res){
    const id = req.params.id;
    await ShippingAddressModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/ship_address', { data: req.data })
        } else {
            res.redirect('/ship_address', { data: req.data })
        }
    }).catch(err => {
        res.redirect('/ship_address', { data: req.data })
    });                     
});
 




module.exports = router;


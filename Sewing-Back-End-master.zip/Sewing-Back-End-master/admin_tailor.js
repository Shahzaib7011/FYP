const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const TailorModel = require("./app/model/user")
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const testimonial = require('./app/model/testimonial');
const upload = multer({ dest: 'uploads/' });
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);



router.get('/tailors',auth.isLogin,  async function(req,res){
    const tailors = await TailorModel.find({ role: 'tailor' });
    res.render("./tailors/index", {tailors: tailors, data: req.data });                      
});
  
router.get('/add-tailor',auth.isLogin, function(req, res){
    res.render("./tailors/add-tailor", { data: req.data });     
});

router.get('/update-tailor/:id',auth.isLogin, async function(req, res){
    const user = await TailorModel.findById(req.params.id);
    res.render("./tailors/update-tailor", {user: user, data: req.data });     
});
  
router.post('/add-tailor',auth.isLogin,upload.single('avatar'), async function(req, res){
    const tailor_image = await uploadImage(req.file.path);
    const user = new TailorModel({
        email: req.body.email,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        phone: req.body.phone,
        password: req.body.password,
        username: req.body.username,
        role: req.body.role,
        image_url: tailor_image
    });
    await user.save().then(data => {
        let message =  req.body.email + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/tailors')
    }).catch(err => {
        console.log(err.message);
        res.redirect('/tailors')
    });
});


router.post('/update-tailor/:id',auth.isLogin, async function(req, res){
    if(!req.body) {
        res.redirect('/tailors')
    }

    const id = req.params.id;
    
    await TailorModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/tailors')
        }else{
            res.redirect('/tailors')
        }
    }).catch(err => {
        res.redirect('/tailors')
    });
});


router.get('/delete-tailor/:id',auth.isLogin,  async function(req, res){
    const id = req.params.id;
    await TailorModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/tailors')
        } else {
            res.redirect('/tailors')
        }
    }).catch(err => {
        res.redirect('/tailors')
    });
});
   

module.exports = router;
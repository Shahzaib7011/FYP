const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const TeamModal = require("./app/model/team")
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);


router.get('/teams',auth.isLogin,  async function(req,res){
    const teams = await TeamModal.find();
    res.render("./teams/index", {teams: teams, data: req.data });                      
});


router.get('/add-teams',auth.isLogin, function(req, res){
    res.render("./teams/add-teams", {  data: req.data });     
});

router.get('/update-teams/:id',auth.isLogin , async function(req, res){
    const team = await TeamModal.findById(req.params.id);
    res.render("./teams/update-teams", {team: team, data: req.data });     
});
  
router.post('/add-teams',auth.isLogin , upload.single('avatar'), async function(req, res){
    const team_image = await uploadImage(req.file.path);
    console.log("Image URL ==============>",team_image);
    const team = new TeamModal({
        name: req.body.name,
        position: req.body.position,
        description: req.body.description,
        phone_number: req.body.phone_number,
        twitter_handle: req.body.twitter_handle,
        facebook_handle: req.body.facebook_handle,
        youtube_handle: req.body.youtube_handle,
        tiktok_handle: req.body.tiktok_handle,
        image_url: team_image
    });
    await team.save().then(data => {
        let message =   req.body.name + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/teams')
    }).catch(err => {
        console.log(err.message);
        res.redirect('/teams')
    });
});


router.post('/update-teams/:id',auth.isLogin , async function(req, res){
    if(!req.body) {
        res.redirect('/teams')
    }

    const id = req.params.id;
    
    await TeamModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/teams')
        }else{
            res.redirect('/teams')
        }
    }).catch(err => {
        res.redirect('/teams')
    });
});


router.get('/delete-teams/:id' ,auth.isLogin ,  async function(req, res){
    const id = req.params.id;
    await TeamModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/teams')
        } else {
            res.redirect('/teams')
        }
    }).catch(err => {
        res.redirect('/teams')
    });
});

module.exports = router;
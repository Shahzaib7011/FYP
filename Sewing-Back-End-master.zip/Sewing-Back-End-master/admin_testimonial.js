const express = require('express');
const bodyParseruser = require('body-parser');
const app = express();
const router = express.Router();
const TestimonialModel = require("./app/model/testimonial")
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const testimonial = require('./app/model/testimonial');
const upload = multer({ dest: 'uploads/' });
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)

    };
    next();
};

router.use(auth.isLogin, setData);



router.get('/testimonials',auth.isLogin, async function(req,res){
    const testimonials = await TestimonialModel.find();
    res.render("./testimonials/index", {testimonials: testimonials,  data: req.data});                      
});

router.get('/add-testimonial',auth.isLogin, function(req,res){
    res.render('./testimonials/add-testimonial', {  data: req.data })
});

router.post('/add-testimonial',auth.isLogin,upload.single('avatar'), async function(req, res){
    const testimonial_image = await uploadImage(req.file.path);
    const testimonial = new TestimonialModel({
        name: req.body.name,
        company: req.body.company,
        position: req.body.position,
        comment: req.body.comment,
        rating: req.body.rating,
        image_url:  testimonial_image
    })
    await testimonial.save().then(data => {
        let message =   req.body.name + " " + "is created successfully"
        const newNotification = new NotificationModal({ text: message });
        newNotification.save();
        res.redirect('/testimonials')
    }).catch(err => {
        console.log(err.message);
        res.redirect('/testimonials')
    });

    
});

router.get('/update-testimonial/:id',auth.isLogin, async function(req, res){
    const testimonial = await TestimonialModel.findById(req.params.id);
    res.render("./testimonials/update-testimonial", {testimonial: testimonial});     
});


router.post('/update-testimonial/:id',auth.isLogin, async function(req, res){
    if(!req.body) {
        res.redirect('/testimonials')
    }

    const id = req.params.id;
    
    await TestimonialModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/testimonials')
        }else{
            res.redirect('/testimonials')
        }
    }).catch(err => {
        res.redirect('/testimonials')
    });
});


router.get('/delete-testimonial/:id',auth.isLogin, async function(req, res){
    const id = req.params.id;
    await TestimonialModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/testimonials')
        } else {
            res.redirect('/testimonials')
        }
    }).catch(err => {
        res.redirect('/testimonials')
    });
});




module.exports = router;

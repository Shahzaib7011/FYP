const express = require('express');
const bodyParseruser = require('body-parser');
const UserModel = require("./app/model/user");
const RoleModel = require("./app/model/role");
const bcrypt = require('bcrypt');
const app = express();
const router = express.Router();
const auth = require('./app/middleware/auth');
const uploadImage = require('./imageUploader');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); // Set destination folder for multer
const NotificationModal = require("./app/model/notification");

// Middleware to set data object
const setData = async function(req, res, next) {
    req.data = {
        full_name: req.session.full_name,
        role: req.session.role,
        image: req.session.image,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)
    };
    next();
};

router.use(auth.isLogin, setData);


router.get('/users',auth.isLogin,async function(req,res){
    const users = await UserModel.find().populate('role', 'title');
    const tailors = users.filter(user => user.role === 'tailor');
    const admins = users.filter(user => user.role === 'admin');
    const customers = users.filter(user => user.role === 'customer');
    res.render("./users/index", {users: users, tailors: tailors, customers: customers, admins: admins, data: req.data });                      
});
  
router.get('/add-user',auth.isLogin, async function(req, res){
    const roles = await RoleModel.find();
    res.render("./users/add-user", { roles: roles, data: req.data});     
});

router.get('/update-user/:id',auth.isLogin, async function(req, res){
    const user = await UserModel.findById(req.params.id);
    res.render("./users/update-user", {user: user});     
});

  
router.post('/add-user', auth.isLogin, upload.single('avatar'), async function(req, res, next) {
    try {
        console.log("File uploaded by user", req.file.path);
        const user_image = await uploadImage(req.file.path);
        console.log("User uploaded Image",user_image);
        const user = new UserModel({
            email: req.body.email,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            phone: req.body.phone,
            password: req.body.password,
            username: req.body.username,
            role: req.body.role,
            image_url: user_image
        });

        // Generate a salt
        bcrypt.genSalt(10, function(err, salt) {
            if (err) {
                console.log(err.message);
                return res.redirect('/users');
            }

            // Hash the password using our new salt
            bcrypt.hash(user.password, salt, function(err, hash) {
                if (err) {
                    console.log(err.message);
                    return res.redirect('/users');
                }
                console.log("Password which user enter", user.password);
                // Override the plaintext password with the hashed one
                // user.password = hash;

                // Save the user to the database
                user.save().then(data => {
                    let message =   req.body.name + " " + "is created successfully"
                    const newNotification = new NotificationModal({ text: message });
                    newNotification.save();
                    res.redirect('/users');
                }).catch(err => {
                    console.log(err.message);
                    res.redirect('/users');
                });
            });
        });
    } catch (err) {
        console.log(err.message);
        res.redirect('/users');
    }
});;


router.post('/update-user/:id', auth.isLogin, async function(req, res) {
    const id = req.params.id;
    const updateData = req.body;

    // Check if password is being updated
    if (updateData.password) {
        // Generate a salt
        bcrypt.genSalt(10, function(err, salt) {
            if (err) {
                console.log(err.message);
                return res.redirect('/users');
            }

            // Hash the password using the new salt
            bcrypt.hash(updateData.password, salt, function(err, hash) {
                if (err) {
                    console.log(err.message);
                    return res.redirect('/users');
                }

                // Override the plaintext password with the hashed one
                updateData.password = hash;

                // Update the user in the database
                UserModel.findByIdAndUpdate(id, updateData, { useFindAndModify: false }).then(data => {
                    if (!data) {
                        res.redirect('/users');
                    } else {
                        res.redirect('/users');
                    }
                }).catch(err => {
                    console.log(err.message);
                    res.redirect('/users');
                });
            });
        });
    } else {
        // If password is not being updated, proceed with the update
        UserModel.findByIdAndUpdate(id, updateData, { useFindAndModify: false }).then(data => {
            if (!data) {
                res.redirect('/users');
            } else {
                res.redirect('/users');
            }
        }).catch(err => {
            console.log(err.message);
            res.redirect('/users');
        });
    }
});


router.get('/settings/:id',auth.isLogin, async function(req, res){
    const user = await UserModel.findById(req.params.id);
    res.render("./profile/update_the_info", {user: user});     
});


router.post('/settings/:id',auth.isLogin , async function(req, res){
    const id = req.params.id;
    await UserModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.redirect('/settings')
        }else{
            res.redirect('/settings')
        }
    }).catch(err => {
        res.redirect('/settings')
    });
});

router.get('/delete-user/:id',auth.isLogin ,  async function(req, res){
    const id = req.params.id;
    await UserModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/users')
        } else {
            res.redirect('/users')
        }
    }).catch(err => {
        res.redirect('/users')
    });
});
   

module.exports = router;

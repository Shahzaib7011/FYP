const User = require('../model/user');
const Notification = require('../model/notification');
const bcrypt = require('bcrypt');
exports.adminlogin = async(req, res) => {
    try {
        res.render("../views/registration/login",{ message: ''}) 
    }
    catch (err) {
        console.log(err.message);
    }
}

exports.settings = async(req, res) => {
    const user_id = req.session.user_id
    const user = await User.findOne({ _id: user_id})
    res.render("./profile/profile.ejs", {user: user});                          
}

exports.update_the_info = async(req, res) => {
    const user_id = req.session.user_id
    const user = await User.findOne({ _id: user_id})
    res.render("./profile/update_the_info.ejs", {user: user});                          
}


exports.update_settings = async(req, res) => {

    const id = req.params.id;
    const updateData = req.body;

    // Check if password is being updated
    if (updateData.password) {
        // Generate a salt
        bcrypt.genSalt(10, function(err, salt) {
            if (err) {
                console.log(err.message);
                return res.redirect('/settings');
            }

            // Hash the password using the new salt
            bcrypt.hash(updateData.password, salt, function(err, hash) {
                if (err) {
                    console.log(err.message);
                    return res.redirect('/settings');
                }

                // Override the plaintext password with the hashed one
                updateData.password = hash;

                // Update the user in the database
                User.findByIdAndUpdate(id, updateData, { useFindAndModify: false }).then(data => {
                    if (!data) {
                        res.redirect('/settings');
                    } else {
                        res.redirect('/settings');
                    }
                }).catch(err => {
                    console.log(err.message);
                    res.redirect('/settings');
                });
            });
        });
    } else {
        // If password is not being updated, proceed with the update
        User.findByIdAndUpdate(id, updateData, { useFindAndModify: false }).then(data => {
            if (!data) {
                res.redirect('/settings');
            } else {
                res.redirect('/settings');
            }
        }).catch(err => {
            console.log(err.message);
            res.redirect('/settings');
        });
    }
}

exports.verifylogin = async(req, res) => {
     try {
        const email = req.body.email;
        const password = req.body.password;

        console.log(req.body);
        const user = await User.findOne({ email: email })
        if(user){
          console.log("User Found Successfully");
          const passwordMatch =  await bcrypt.compare(password, user.password)
          if(passwordMatch)
          {
            console.log("Password matched")
            if(user.role !== "admin")
            {
              res.render("../views/registration/login", { message: 'Please enter correct email and password'})

            }
            else
            {
                req.session.user_id =  user._id
                req.session.role = user.role
                req.session.full_name = user.firstName + ' ' + user.lastName
                req.session.image = user.image_url
                const newNotification = new Notification({ text: 'Successfully login into system ' });
                await newNotification.save();
                res.redirect('/')
            }

          }
          else
          {
            res.render("../views/registration/login", { message: 'You are not allow to login'})
          }
        }
        else
        {
            res.render("../views/registration/login", { message: "Password does n't match"})
        }
    }
    catch (err) {
        res.render("../views/registration/login", { message: "Something went wrong"})
    }
}

exports.logout = async(req, res) => {
    try {
        req.session.destroy()
        res.render("../views/registration/login", { message: 'Successfully log out'}) 
    }
    catch (err) {
        console.log(err.message);
    }
}


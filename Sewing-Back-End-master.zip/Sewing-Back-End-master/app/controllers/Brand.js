const BrandModel = require('../model/brand')


// Create and Save a new faq
exports.create = async (req, res) => {
    if (!req.body.title && !req.body.product) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const brand = new BrandModel({
        title: req.body.title,
        product: req.body.product
    });
    
    await brand.save().then(data => {
        res.send({
            message:"Brand created successfully!!",
            brand:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};


// Retrieve all faqs from the database.
exports.findAll = async (req, res) => {
    try {
        const brand = await BrandModel.find();
        res.status(200).json(brand);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


// Find a single faq with an id
exports.findOne = async (req, res) => {
    try {
        const brand = await BrandModel.findById(req.params.id);
        res.status(200).json(brand);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};



// Delete a faq with the specified id in the request
exports.destroy = async (req, res) => {
    await BrandModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Brand not found.`
          });
        } else {
          res.send({
            message: "Brand deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};



// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await BrandModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Brand not found.`
            });
        }else{
            res.send({ message: "Brand updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
const ContactUsModal = require('../model/contact_us')
const ProductModal = require('../model/product');


exports.contact_us_screen = async (req, res) => {
    const randomProducts = await ProductModal.aggregate([{ $sample: { size: 10 } }]);
     res.status(200).json({products: randomProducts});
}

exports.create = async (req, res) => {
    if (!req.body.email && !req.body.subject && !req.body.message) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const contact_us = new ContactUsModal({
        email: req.body.email,
        subject: req.body.subject,
        message: req.body.message
    
    });
    
    await contact_us.save().then(data => {
        res.send({
            message:"Form submitted successfully!!",
            faq:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};




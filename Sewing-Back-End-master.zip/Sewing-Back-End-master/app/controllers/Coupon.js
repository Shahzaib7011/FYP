const CouponModal = require('../model/coupon')


// Create and Save a new faq
exports.create = async (req, res) => {

    try {
        if (!req.body.title && !req.body.description && !req.body.available_count && !req.body.used_count && !req.body.user) {
            res.status(400).send({ message: "Content can not be empty!" });
        }
        
        const coupon_modal = new CouponModal({
            title: req.body.title,
            description: req.body.description,
            available_count: req.body.available_count,
            used_count: req.body.used_count,
            price: req.body.price,
            user: req.body.user 
        });

        await coupon_modal.validate();

        
        await coupon_modal.save().then(data => {
            res.send({
                message:"Coupon created successfully!!",
                coupon_modal:data
            });
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while creating user"
            });
        });
    } 
    catch (error) {
        // If validation or database save fails, handle the error
        res.status(500).send({
            message: error.message || "Some error occurred while creating coupon"
        });
    }
};


// Retrieve all faqs from the database.
exports.findAll = async (req, res) => {
    try {
        const coupon_modal = await CouponModal.find();
        res.status(200).json(coupon_modal);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


// Find a single faq with an id
exports.findOne = async (req, res) => {
    try {
        const coupon_modal = await CouponModal.findById(req.params.id);
        res.status(200).json(coupon_modal);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};



// Delete a faq with the specified id in the request
exports.destroy = async (req, res) => {
    await CouponModal.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Coupon not found.`
          });
        } else {
          res.send({
            message: "Coupon deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};



// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await CouponModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Coupon not found.`
            });
        }else{
            res.send({ message: "Coupon updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
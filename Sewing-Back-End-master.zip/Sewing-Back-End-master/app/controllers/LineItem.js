const LineItemModel = require('../model/line_item')


// Create and Save a new faq
exports.create = async (req, res) => {
    if (!req.body.user && !req.body.product && !req.body.variant) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const line_item = new LineItemModel({
        user: req.body.user,
        variant: req.body.variant,
        product: req.body.product 
    });
    
    await line_item.save().then(data => {
        res.send({
            message:"Line Item created successfully!!",
            line_item:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};


// Retrieve all faqs from the database.
exports.findAll = async (req, res) => {
    try {
        const line_item = await LineItemModel.find();
        res.status(200).json(line_item);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


// Find a single faq with an id
exports.findOne = async (req, res) => {
    try {
        const line_item = await LineItemModel.findById(req.params.id);
        res.status(200).json(line_item);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};



// Delete a faq with the specified id in the request
exports.destroy = async (req, res) => {
    await LineItemModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Line Item not found.`
          });
        } else {
          res.send({
            message: "Line Item deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};



// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await LineItemModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Line Item not found.`
            });
        }else{
            res.send({ message: "Line Item updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
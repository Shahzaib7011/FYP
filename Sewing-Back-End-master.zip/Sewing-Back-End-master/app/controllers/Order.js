const OrderModel = require('../model/order')
const LineItemModel = require('../model/line_item')


exports.create = async (req, res) => {
    console.log(req.body)
    if (!req.body.user || !req.body.billing_address || !req.body.shipping_address) {
        return res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const order = new OrderModel({
        billing_address: req.body.billing_address,
        shipping_address: req.body.shipping_address,
        status: req.body.status,
        user: req.body.user,
        delivery_charges: req.body.delivery_charges,
        order_total: req.body.order_total,
        item_total: req.body.item_total,
        tax_rate: req.body.tax_rate
    });
    try 
    {
        const savedOrder = await order.save();
        const lineItems = req.body.lineItems;
        const createdLineItems = await LineItemModel.create(lineItems.map(item => ({
            product: item.product,
            order: savedOrder._id,
            quantity: item.quantity,
            price: item.price,
            name: item.name,
            image_url: item.image_url
        })));
        
        res.send({
            message: "Order created successfully!!",
            order: savedOrder,
            lineItems: createdLineItems,
        });
    } catch (err) {
        res.status(500).send({
            message: err.message || "Some error occurred while creating order"
        });
    }
};


// Retrieve all faqs from the database.
exports.findAll = async (req, res) => {
    try {
        const id = req.query.user
        const line_item = await LineItemModel.find().populate('product order')
        res.status(200).json(line_item);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


// Find a single faq with an id
exports.findOne = async (req, res) => {
    try {
        const order = await OrderModel.findById(req.params.id);
        res.status(200).json(order);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};



// Delete a faq with the specified id in the request
exports.destroy = async (req, res) => {
    await OrderModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Order not found.`
          });
        } else {
          res.send({
            message: "Order deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};


exports.get_specific_user = async (req, res) => {
    try {
        const user_id = req.params.user_id;
        const orders = await OrderModel.find({ user: user_id });
        res.status(200).json(orders);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error', error });
    }
};

// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await OrderModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Order not found.`
            });
        }else{
            res.send({ message: "Order updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
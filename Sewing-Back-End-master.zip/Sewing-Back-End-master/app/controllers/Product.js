const ProductModel = require('../model/product');
const UserModel = require("../model/user");
const TestimonialModel = require("../model/testimonial");


exports.create = async (req, res) => {
    if (!req.body.title && !req.body.description && !req.body.sale_price && !req.body.list_price && !req.body.shop) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const product = new ProductModel({
        title: req.body.title,
        description: req.body.description,
        sale_price: req.body.sale_price,
        list_price: req.body.list_price,
        shop: req.body.shop,
        stock: req.body.stock,
        category: req.body.category
    });
    
    await product.save().then(data => {
        res.send({
            message:"Product created successfully!!",
            product:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};

exports.home_screen = async (req, res) => {
      try {
        const users = await UserModel.find();
        const testimonials = await TestimonialModel.find();
        const tailors = users.filter(user => user.role === 'tailor');
        const product = await ProductModel.find();
        const randomImages = await ProductModel.aggregate([{ $sample: { size: 10 } }]);
        const imageUrls = randomImages.map(product => product.image_url);
        const randomTailors =  await UserModel.aggregate([
            { $match: { role: 'tailor' } }, // Match documents with the role 'tailor'
            { $sample: { size: 10 } } // Get random documents
        ]);
        const tailorsUrls = randomTailors.map(tailor => tailor.image_url);
        res.status(200).json({ product: product, tailors: tailors, testimonials: testimonials, ProductimageUrls: imageUrls, tailorsUrls: tailorsUrls  });
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};

// Retrieve all faqs from the database.
exports.findAll = async (req, res) => {
    try {
        const product = await ProductModel.find();
        res.status(200).json(product);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


// Find a single faq with an id
exports.findOne = async (req, res) => {
    try {
        const product = await ProductModel.findById(req.params.id);
        res.status(200).json(product);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};



// Delete a faq with the specified id in the request
exports.destroy = async (req, res) => {
    await ProductModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Product not found.`
          });
        } else {
          res.send({
            message: "Product deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};



// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await ProductModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Product not found.`
            });
        }else{
            res.send({ message: "Product updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
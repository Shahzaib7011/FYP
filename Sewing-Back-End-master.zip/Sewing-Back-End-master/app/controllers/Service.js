const ProductModel = require('../model/product');
const ServiceModal = require("../model/service");


exports.services_screen = async (req, res) => {
      try {
        const randomProducts = await ProductModel.aggregate([{ $sample: { size: 10 } }]);
        const services = await ServiceModal.find()
        res.status(200).json({ products: randomProducts, services: services});
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


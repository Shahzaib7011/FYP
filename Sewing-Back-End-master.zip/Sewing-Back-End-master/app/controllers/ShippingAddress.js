const ShippingAddressModel = require('../model/shipping_address')


// Create and Save a new faq
exports.create = async (req, res) => {
    if (!req.body.house_number && !req.body.street && !req.body.zipcode && !req.body.city && !req.body.country) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const shipping_address = new ShippingAddressModel({
        address1: req.body.address1,
        street: req.body.street,
        zipcode: req.body.zipcode,
        city: req.body.city,
        country: req.body.country,
        user: req.body.user,
    });
    
    await shipping_address.save().then(data => {
        res.send({
            message:"shipping address created successfully!!",
            shipping_address:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};

// Retrieve all faqs from the database.
exports.findAll = async (req, res) => {
    try {
        const ShippingAddress = await ShippingAddressModel.find();
        res.status(200).json(ShippingAddress);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};


// // Find a single faq with an id
exports.findOne = async (req, res) => {
    try {
        const shipping_address = await ShippingAddressModel.findById(req.params.id);
        res.status(200).json(shipping_address);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};



// // Delete a faq with the specified id in the request
exports.destroy = async (req, res) => {
    await ShippingAddressModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Shipping Address not found.`
          });
        } else {
          res.send({
            message: "Shipping Address deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};



// // Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await ShippingAddressModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Shipping Address not found.`
            });
        }else{
            res.send({ message: "Shipping Address updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
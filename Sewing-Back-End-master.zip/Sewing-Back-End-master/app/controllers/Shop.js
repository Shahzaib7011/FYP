const ShopModal = require('../model/shop')

exports.create = async (req, res) => {
    if (!req.body.title && !req.body.address && !req.body.verified && !req.body.certified && !req.body.phone_number && !req.body.opening_time && !req.body.closing_time && !req.body.user) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const shop = new ShopModal({
        title: req.body.title,
        address: req.body.address,
        verified: req.body.verified,
        certified: req.body.certified,
        phone_number: req.body.phone_number,
        opening_time: req.body.opening_time,
        closing_time: req.body.closing_time,
        user: req.body.user,
    });
    
    await shop.save().then(data => {
        res.send({
            message:"Shop created successfully!!",
            shop:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};

// Retrieve all users from the database.
exports.findAll = async (req, res) => {
    try {
        const shop = await ShopModal.find();
        res.status(200).json(shop);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};
// Find a single User with an id
exports.findOne = async (req, res) => {
    try {
        const shop = await ShopModal.findById(req.params.id);
        res.status(200).json(shop);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};
// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await ShopModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Shop not found.`
            });
        }else{
            res.send({ message: "Shop updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
// Delete a user with the specified id in the request
exports.destroy = async (req, res) => {
    await ShopModal.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Shop not found.`
          });
        } else {
          res.send({
            message: "Shop deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};
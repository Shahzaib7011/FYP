const TeamModal = require('../model/team');
const ProductModal = require('../model/product');


exports.get_info = async(req, res) => {
    try {
        const team = await TeamModal.find();
        const randomProducts = await ProductModal.aggregate([{ $sample: { size: 10 } }]);
        res.status(200).json({teams: team, products: randomProducts});
    }
    catch (err) {
        console.log(err.message);
        res.status(404).json({message: error.message});
    }
}
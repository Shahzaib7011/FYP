const UserModel = require('../model/user')
const BillingAddressModel = require('../model/billing_address')
const ShippingAddressModel = require('../model/shipping_address')
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');

// Create and Save a new user
exports.create = async (req, res) => {
    if (!req.body) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const user = new UserModel({
        email: req.body.email,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        phone: req.body.phone,
        password: req.body.password,
        username: req.body.username,
        experience: req.body.experience,
        role: req.body.role,
        latitude: req.body.latitude,
        longitude: req.body.longitude,
        address: req.body.address
    });
    
    console.log("DATA Which is coming from the api ==============>>", user);
    await user.save().then(data => {
        
                
                    // Import the Nodemailer library
                var transporter = nodemailer.createTransport({
                    host: "sandbox.smtp.mailtrap.io",
                    port: 2525,
                    auth: {
                        user: "6f01117c922804",
                        pass: "5df2df34625ece"
                    }
                    });

                // Configure the mailoptions object
                const mailOptions = {
                from: 'suidhaga@email.com',
                to: user.email,
                subject: 'Sending Email using Node.js',
                text: `Congrats ${user.email} You have been register to sui dhage platform successfully `
                };

                // Send the email
                transporter.sendMail(mailOptions, function(error, info){
                if (error) {
                    console.log("----------------------------------")
                    console.log('Error:', error);
                    console.log("----------------------------------")

                } else {
                    console.log("----------------------------------")
                    console.log("----------------------------------")

                    console.log('Email sent:', info.response);
                    console.log("----------------------------------")

                    console.log("----------------------------------")

                }
                });


        res.send({
            message:"User created successfully!!",
            user:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};


exports.tailors_info = async (req, res) => {
    try {
        const tailors = await UserModel.find({ role: 'tailor' });
        res.status(200).json({
            tailors: tailors
        });
    }
    catch (err) {
        res.status(404).json({ message: err.message});
    }
}


exports.user_login = async (req, res) => {
  try{
     if (!req.body) {
        res.status(400).send({ message: "Content can not be empty!" });
     }

     const email = req.body.email;
     const password = req.body.password;

     UserModel.findOne({ email: email }).then((user) => {
    if (!user) {
        // If user with the given email is not found
        console.log('User not found');
        // Send an appropriate response to the client
        return res.status(401).json({ message: 'User not found' });
    }

    // User found, now compare the password
    bcrypt.compare(password, user.password).then((isMatch) => {
        if (!isMatch) {
            // If passwords don't match
            console.log('Incorrect password');
            // Send an appropriate response to the client
            return res.status(401).json({ message: 'Incorrect password' });
        }

        // Passwords match, user authenticated
        console.log('User authenticated');
        // Send an appropriate response to the client
        return res.status(200).json({ message: 'User authenticated', user: user});
    }).catch((compareErr) => {
        // Handle error
        console.error('Error comparing passwords:', compareErr);
        // Send an appropriate response to the client
        return res.status(500).send('Internal Server Error');
    });
}).catch((err) => {
    // Handle error
    console.error('Error finding user by email:', err);
    // Send an appropriate response to the client
    return res.status(500).send('Internal Server Error');
});
  }
  catch (err) {
    res.status(404).json({ message: err.message});
  }
}

// Retrieve all users from the database.
exports.findAll = async (req, res) => {
    try {
        const user = await UserModel.find();
        res.status(200).json({ user: user});
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};
// Find a single User with an id
exports.findOne = async (req, res) => {
    try {
        const user = await UserModel.findById(req.params.id);
        const userAddresses = await BillingAddressModel.find({ user: user.id });
        const user_shipping_address = await ShippingAddressModel.find({ user: user.id });
        res.status(200).json({
            user: user,
            billing_address: userAddresses,
            shipping_address: user_shipping_address,
        });
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};
// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await UserModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `User not found.`
            });
        }else{
            res.send({ message: "User updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
// Delete a user with the specified id in the request
exports.destroy = async (req, res) => {
    await UserModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `User not found.`
          });
        } else {
          res.send({
            message: "User deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};


// module.exports.getAllUsers = async (req, res, next) => {
//     try {
//       const users = await User.find({ _id: { $ne: req.params.id } }).select([
//         "email",
//         "username",
//         "avatarImage",
//         "_id",
//       ]);
//       return res.json(users);
//     } catch (ex) {
//       next(ex);
//     }
//   };
  
//   module.exports.setAvatar = async (req, res, next) => {
//     try {
//       const userId = req.params.id;
//       const avatarImage = req.body.image;
//       const userData = await User.findByIdAndUpdate(
//         userId,
//         {
//           isAvatarImageSet: true,
//           avatarImage,
//         },
//         { new: true }
//       );
//       return res.json({
//         isSet: userData.isAvatarImageSet,
//         image: userData.avatarImage,
//       });
//     } catch (ex) {
//       next(ex);
//     }
//   };
  
//   module.exports.logOut = (req, res, next) => {
//     try {
//       if (!req.params.id) return res.json({ msg: "User id is required " });
//       onlineUsers.delete(req.params.id);
//       return res.status(200).send();
//     } catch (ex) {
//       next(ex);
//     }
//   };
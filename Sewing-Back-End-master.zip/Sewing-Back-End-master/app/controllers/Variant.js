const VariantModal = require('../model/variant')

exports.create = async (req, res) => {
    if (!req.body.size && !req.body.color && !req.body.quantities && !req.body.remaining_quantities && !req.body.out_of_stock && !req.body.product ) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const shop = new VariantModal({
        size: req.body.size,
        color: req.body.color,
        quantities: req.body.quantities,
        remaining_quantities: req.body.remaining_quantities,
        out_of_stock: req.body.out_of_stock,
        product: req.body.product
    });
    
    await shop.save().then(data => {
        res.send({
            message:"Variant created successfully!!",
            variant:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};

// Retrieve all users from the database.
exports.findAll = async (req, res) => {
    try {
        const shop = await VariantModal.find();
        res.status(200).json(shop);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};
// Find a single User with an id
exports.findOne = async (req, res) => {
    try {
        const shop = await VariantModal.findById(req.params.id);
        res.status(200).json(shop);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};
// Update a user by the id in the request
exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
    
    const id = req.params.id;
    
    await VariantModal.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Variant not found.`
            });
        }else{
            res.send({ message: "Variant updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
// Delete a user with the specified id in the request
exports.destroy = async (req, res) => {
    await VariantModal.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Variant not found.`
          });
        } else {
          res.send({
            message: "Variant deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};
const FavouriteModel = require('../model/favourite');

exports.create = async (req, res) => {
    if (!req.body.user && !req.body.product) {
        res.status(400).send({ message: "Content can not be empty!" });
    }
    
    const fav_item = new FavouriteModel({
        product: req.body.product,
        user: req.body.user,
        name: req.body.name,
        price: req.body.price,
        image_url: req.body.image_url,
    });
    await fav_item.save().then(data => {
        res.send({
            message:"Favourite Item Save successfully!!",
            faq:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};


exports.findAll = async (req, res) => {
    try {
        const fav_item = await FavouriteModel.find();
        res.status(200).json(fav_item);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};

exports.findOne = async (req, res) => {
    try {
        const fav_item = await FavouriteModel.findById(req.params.id);
        res.status(200).json(fav_item);
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};


exports.destroy = async (req, res) => {
    await FavouriteModel.findOneAndDelete(req.params.id).then(data => {
        if (!data) {
          res.status(404).send({
            message: `Favourite Item not found.`
          });
        } else {
          res.send({
            message: "Favourite Item deleted successfully!"
          });
        }
    }).catch(err => {
        res.status(500).send({
          message: err.message
        });
    });
};
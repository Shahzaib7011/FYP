exports.isLogin = (req, res, next) => {
    if(req.session){ 
        if (req.session.user_id) {
            res.locals.currentRoute = req.originalUrl;
            next();
        } else {
            // User is not logged in, redirect to login page
            res.redirect('/login');
        }
    } else {
        res.redirect('/login');
    }
};

exports.isLogout = (req, res, next) => {
    if (req.session.user_id) {
        res.redirect('/');
    } else {
        // User is not logged in, proceed to the next middleware or route handler
        next();
    }
};
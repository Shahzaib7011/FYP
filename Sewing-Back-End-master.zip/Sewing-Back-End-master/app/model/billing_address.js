
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    address1: {
        type: String,
        default: ''
        },
    state: {
        type: String,
        default: ''
    },
    zipcode: {
        type: String,
        default: ''
    },
    city: {
        type: String,
        default: ''
    },
    country: {
        type: String,
        default: ''
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
});

var billing_address = new mongoose.model('BillingAddress', schema);
module.exports = billing_address;

var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    title: {
        type: String,
        default: ''
        },
    slug: {
        type: String,
        default: ''
    },
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product"
    }
});

var brand = new mongoose.model('Brand', schema);
module.exports = brand;
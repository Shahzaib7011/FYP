
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    title: {
        type: String,
        default: ''
     },
     image_url: {
        type: String,
        default: ''
     }
});

var category = new mongoose.model('Category', schema);
module.exports = category;
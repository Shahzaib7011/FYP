
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    email: {
        type: String,
        default: ''
     },
     subject: {
        type: String,
        default: ''
     },
     message: {
        type: String,
        default: ''
     },
     replied: {
        type: Boolean,
        default: false
     }
});

var contact_us = new mongoose.model('ContactUs', schema);
module.exports = contact_us;
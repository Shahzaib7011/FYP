
var mongoose = require('mongoose');
const { Decimal128 } = require('mongodb');

var schema = new mongoose.Schema({
    title: {
        type: String,
        default: ''
    },
    description: {
        type: String,
        default: ''
    },
    available_count: {
        type: Number,
        default: 0,
        validate: {
            validator: Number.isInteger,
            message: 'Available Count is not an integer value'
        }
    },
    used_count: {
        type: Number,
        default: 0,
        validate: {
            validator: Number.isInteger,
            message: 'Used Count is not an integer value'
        }
    },
    price: {
        type: Decimal128,
        default: 0
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
});

var coupon = new mongoose.model('Coupon', schema);
module.exports = coupon;
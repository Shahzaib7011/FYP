var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    question: {
        type: String,
        required: true
    },
    answer: {
        type: String,
        required: true
    },
    tag_line: {
        type: String,
        required: true,
    },
    completed: {
        type: Boolean,
        default: false
    }
});
var faq = new mongoose.model('Faq', schema);
module.exports = faq;
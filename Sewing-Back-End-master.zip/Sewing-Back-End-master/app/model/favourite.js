
const { Decimal128 } = require('mongodb');
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    product: {
        type: mongoose.Schema.Types.ObjectId,
        default: 'Product'
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    name: {
        type: mongoose.Schema.Types.String,
        required: true
    },
    quantity: {
        type: Number,
        default: 1
    },
    price: {
        type: Decimal128,
        required: false
    },
    image_url: {
        type: String,
        default: ''
    }
});

var favourite_item = new mongoose.model('Favourite', schema);
module.exports = favourite_item;
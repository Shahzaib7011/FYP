
const { Decimal128 } = require('mongodb');
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    product: {
        type: mongoose.Schema.Types.ObjectId,
        default: 'Product'
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order"
    },
    name: {
        type: mongoose.Schema.Types.String,
        required: true
    },
    quantity: {
        type: Number,
        default: 1
    },
    price: {
        type: Decimal128,
        required: false
    },
    image_url: {
        type: String,
        default: ''
    }
});

var line_item = new mongoose.model('LineItem', schema);
module.exports = line_item;
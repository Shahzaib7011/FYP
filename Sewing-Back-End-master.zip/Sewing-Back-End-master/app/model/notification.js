var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    text: {
        type: String,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
  
});
var notification = new mongoose.model('Notification', schema);
module.exports = notification;

var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    order_number: {
        type: String,
        default: ''
        },
    tax_rate: {
        type: String,
        default: ''
    },
    delivery_charges: {
        type: String,
        default: ''
    },
    order_total: {
        type: String,
        default: ''
    },
    item_total: {
        type: String,
        default: ''
    },
    status: {
      type: String,
      default: 'pending'
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    shipping_address: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ShippingAddress"
    },
    billing_address: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "BillingAddress"
    },
    created_at: {
      type: Date,
      default: Date.now
    }
    
});


schema.pre('save', async function(next) {
    // Generate the order number dynamically (for example, using a timestamp)
    const timestamp = Date.now().toString();
    this.order_number = timestamp;

    next();
});


var order = new mongoose.model('Order', schema);
module.exports = order;
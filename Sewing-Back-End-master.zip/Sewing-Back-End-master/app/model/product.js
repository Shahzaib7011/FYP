const { Decimal128 } = require('mongodb');
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    list_price: {
        type: Decimal128,
        required: true
    },
    sale_price: {
        type: Decimal128,
        required: false
    },
    stock: {
        type: Number,
        required: true
    },
    shop: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Shop"
    },
    category: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category"
    },
    image_url: {
        type: String,
        default: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAswMBIgACEQEDEQH/xAAbAAEBAAMBAQEAAAAAAAAAAAAAAQIEBQMGB//EADUQAAICAQEFBAkEAQUAAAAAAAABAgMRBAUSEyExQVFhkRUiMjM1UlNy0RQjcXNCJGKBscH/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8A/cCgAAAAAAAAAQFAAAAQFAEBQBAUAQFAEBQBAUAAAABABQQAUEAFBCgAQAUEAFBDT12s4GKqVv3z6LuA2lbB2OtTW+lndzzwZmloNE6W7bnv3z6vu8DcAoIAKCACggAoAAAAAa+s1UdJCMpxck3jkbBzdt+5p/sAPa1f0LfIelq/oXeR0W8c+w4+o2vPiNaeMd1P2pLOQPf0tD6NvkPS1f0bfIy2ftD9TJ12pRsxlY6M9NZro6a2uD57z9b/AGrvA8fS1f0LfIelq/oW+R0VzSafJlA5vpav6NvkPS1f0LfI6Jpa/W8DFVKc75coxXYBhqNobtUY11y49nswfVeLNaiyvR2SlbCy7UP2pJZw+5G5oNHwf3bvWvl1b7DdwBo0bSrtujUqpxcu83jnar4vpvt/J0V0AAoAgKAICgACBAUAADm7c91T/YdI5u2/c1feBv2xcoSiu1NHy04Srm4TWGnho+sPG7TU3PNtUZNdG0BwtmLd1HHfKupNyf8AxjB4X3SvulZP2pPyRv7WthWo6WmKjFc5KPQ5q5AdzY+q4tPCm/Xr6eKOj2Hy+lvlRfGyPY+a70drWa1VxjCn1rp+zHuAuu1nBxVSt++XSK7BoNG6c23Pevnzk+4mg0fBbuue/fPq+7wRugUAAc3VfF9N9v5OiuhztV8X032/k6K6AUAgFAAAAAQpEUAAABzdt+5q+86Rzdt+5q+8DpHhqr46emdkuzou9nscLa+p4t/Di/UrfmwNGU5TnKUnlyeWY5Lg2qa+BuTlDevl7uvrjxYCqvgbspQ3tRP3deOnizd2cqYaqUbJb+qksuXVLwRp22cDfSnv6mXt2d3gjWqnKqyNkHiUXkD6o5u09fKmca6Gt5PMn/4et20IQ0Ub4tb01iMfE4Mm5ScpPLby2wPpdLfHUUqyHb1Xcz2Pndnar9Nf6z/bl7S7vE+hi00muafagOfqvi+m+38nROdqvi+m+38nRAAAAAAAAApCgAAABzdt+6p/sOkc3bmODU+6eQPfaOp/T6dtP15conzjb7zranVaDVTTt4zwsLCwjC2Olo3OBVN3y5wjPnjxaA16q+AoSlHevl7uvGceLFtn6dSSlv6iXvLF/j4I96rNNp3Naic56iXtTgs48EzHOy89LgNAG/nZfy3De2X8twGjnljPIhv52X8twzsv5bgNA6+x9Zn/AE9j5/4fg187L+W4sZ7MjKMo8dNPKazyA29V8X032/k6K6HI/U16namnlVvNJYeV/J110AoAAAAAAAICgCAMACOKl7STXiinjq5Wxok6I71mOSA1tfqa6MVVVxlfL2YpdPEz0Oj4ObbXvXy9pvsGg0fB/duanfLrLuNwDHhw7YR8hw6/kj5GQAx4dfyR8hw6/px8kZADHh1/JHyHDr+SPkZADHh1/JHyHDr+SPkZADFQgnlQin/BkAAAAAAACkAAFAAhQAAAA8tRZwap2Yb3VnC7T1PLVQdlE4R5trCAxWoi41SjzU5bvPquv4M42QlJxjOLkuqya9unnx4Tra3HLemn2PDWV5kqpsXAg4KKqbbln2uT6eYGxKxRm1LCio53sjj1cv3Ic3hczx1NE7JTccNOCS59ucksolJ34ivX3d1/wBscWtz3FOO93ZJG6uTxGyLaXYzWnXa7VOaajGbk8NY3cPu55PCqMrK1XlOcqt1c01FcuTA6ULITzuSUsdzMjX09bUpTlGcW1j1pZ/6NkAAABCgCFAAAAACFAEDAAAAACgCFIwAAABJdwCAAMAAABSAAAAAKQACgARgAAAAAAAAAAAAAAAFAAgAAAAAAAAAA/9k='
    },
    latitude: {
        type: String,
        default: ''
    },
    longitude: {
        type: String,
        default: ''
    },
    address: {
        type: String,
        default: ''
    }

});
var product = new mongoose.model('Product', schema);
module.exports = product;
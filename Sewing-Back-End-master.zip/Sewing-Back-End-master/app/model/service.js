const { Decimal128 } = require('mongodb');
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    tag_line: {
        type: String,
        required: true
    },
    item_included_one: {
        type: String,
        default: ''
    },
    item_included_two: {
        type: String,
        default: ''
    },
    item_included_three: {
        type: String,
        default: ''
    },
    tailors_count: {
        type: Number,
        default: 0
    },
    premium_support_days: {
        type: Number,
        default: 0
    },
    free_updates_days: {
        type: Number,
        default: 0
    },
    price: {
        type: Decimal128,
        default: 0
    }

});
var service = new mongoose.model('Service', schema);
module.exports = service;
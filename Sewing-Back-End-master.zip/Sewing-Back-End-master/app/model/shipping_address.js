
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    street: {
        type: String,
        default: ''
        },
    address1: {
        type: String,
        default: ''
    },
    zipcode: {
        type: String,
        default: ''
    },
    city: {
        type: String,
        default: ''
    },
    country: {
        type: String,
        default: ''
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
});

var shipping_address = new mongoose.model('ShippingAddress', schema);
module.exports = shipping_address;
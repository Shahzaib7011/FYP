
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    title: {
        type: String,
        default: ''
        },
    address: {
        type: String,
        default: ''
    },
    verified: {
        type: Boolean,
        default: false
    },
    certified: {
        type: Boolean,
        default: false
    },
    phone_number: {
        type: String,
        default: ''
    },
    opening_time: {
        type: String,
        default: ''
    },
    closing_time: {
        type: String,
        default: ''
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
    
});

var shop = new mongoose.model('Shop', schema);
module.exports = shop;
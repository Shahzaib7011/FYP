
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    name: {
        type: String,
        default: ''
        },
    position: {
        type: String,
        default: ''
    },
    description: {
        type: String,
        default: ''
    },
    image_url: {
        type: String,
        default: ''
    },
    phone_number: {
        type: String,
        default: ''
    },
    youtube_handle: {
        type: String,
        default: ''
    },
    twitter_handle: {
        type: String,
        default: ''
    },
    facebook_handle: {
        type: String,
        default: ''
    },
    tiktok_handle: {
        type: String,
        default: ''
    }
});

var team = new mongoose.model('Team', schema);
module.exports = team;
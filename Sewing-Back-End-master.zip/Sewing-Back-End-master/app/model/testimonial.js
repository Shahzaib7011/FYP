
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    name: {
        type: String,
        default: ''
        },
    image_url: {
        type: String,
        default: ''
    },
    comment: {
        type: String,
        default: ''
    },
    position: {
        type: String,
        default: ''
    },
    company: {
        type: String,
        default: ''
    },
    rating: {
        type: Number,
        default: 0
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
});

var testimonial = new mongoose.model('Testimonial', schema);
module.exports = testimonial;
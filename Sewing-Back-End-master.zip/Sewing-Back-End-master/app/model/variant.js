const { Decimal128 } = require('mongodb');
var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    size: {
        type: String,
        required: true
    },
    color: {
        type: String,
        required: true
    },
    quantities: {
        type: Decimal128,
        required: true
    },
    remaining_quantities: {
        type: Decimal128,
        required: false
    },
    out_of_stock: {
        type: Boolean,
        default: false,
        required: false
    },
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product'
    }
});
var variant = new mongoose.model('Variant', schema);
module.exports = variant;
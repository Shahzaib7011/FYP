const express = require('express')
const BillingAddressController = require('../controllers/BillingAddress')
const router = express.Router();

router.get('/', BillingAddressController.findAll);
router.get('/:id', BillingAddressController.findOne);
router.post('/', BillingAddressController.create);
router.patch('/:id', BillingAddressController.update);
router.delete('/:id', BillingAddressController.destroy);

module.exports = router

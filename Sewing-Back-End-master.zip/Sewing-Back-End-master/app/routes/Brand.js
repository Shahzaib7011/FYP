const express = require('express')
const BrandController = require('../controllers/Brand')
const router = express.Router();

router.get('/', BrandController.findAll);
router.get('/:id', BrandController.findOne);
router.post('/', BrandController.create);
router.patch('/:id', BrandController.update);
router.delete('/:id', BrandController.destroy);

module.exports = router

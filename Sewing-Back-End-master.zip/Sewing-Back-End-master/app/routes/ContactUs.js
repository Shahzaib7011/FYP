const express = require('express')
const ContactUsController = require('../controllers/ContactUs')
const router = express.Router();

router.get('/', ContactUsController.contact_us_screen);
router.post('/', ContactUsController.create);

module.exports = router

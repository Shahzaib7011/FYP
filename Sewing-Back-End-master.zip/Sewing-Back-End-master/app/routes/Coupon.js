const express = require('express')
const CouponController = require('../controllers/Coupon')
const router = express.Router();

router.get('/', CouponController.findAll);
router.get('/:id', CouponController.findOne);
router.post('/', CouponController.create);
router.patch('/:id', CouponController.update);
router.delete('/:id', CouponController.destroy);

module.exports = router

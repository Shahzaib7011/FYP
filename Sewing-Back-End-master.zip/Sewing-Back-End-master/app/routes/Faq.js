const express = require('express')
const FaqController = require('../controllers/Faq')
const router = express.Router();

router.get('/', FaqController.findAll);
router.get('/:id', FaqController.findOne);
router.post('/', FaqController.create);
router.patch('/:id', FaqController.update);
router.delete('/:id', FaqController.destroy);

module.exports = router

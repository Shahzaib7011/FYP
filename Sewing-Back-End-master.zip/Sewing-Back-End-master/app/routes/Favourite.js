const express = require('express')
const FavController = require('../controllers/favourite')
const router = express.Router();

router.get('/', FavController.findAll);
router.get('/:id', FavController.findOne);
router.post('/', FavController.create);
router.delete('/:id', FavController.destroy);

module.exports = router

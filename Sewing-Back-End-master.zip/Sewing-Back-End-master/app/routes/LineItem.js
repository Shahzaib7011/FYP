const express = require('express')
const LineItemController = require('../controllers/LineItem')
const router = express.Router();

router.get('/', LineItemController.findAll);
router.get('/:id', LineItemController.findOne);
router.post('/', LineItemController.create);
router.patch('/:id', LineItemController.update);
router.delete('/:id', LineItemController.destroy);

module.exports = router

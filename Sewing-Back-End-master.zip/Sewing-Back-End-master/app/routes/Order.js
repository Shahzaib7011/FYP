const express = require('express')
const OrderController = require('../controllers/Order')
const router = express.Router();

router.get('/', OrderController.findAll);
router.get('/:id', OrderController.findOne);
router.post('/', OrderController.create);
router.get('/get_specific_user/:user_id', OrderController.get_specific_user);
router.patch('/:id', OrderController.update);
router.delete('/:id', OrderController.destroy);

module.exports = router

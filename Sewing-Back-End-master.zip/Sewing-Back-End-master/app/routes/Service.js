const express = require('express')
const ServiceController = require('../controllers/Service')
const router = express.Router();

router.get('/service_page', ServiceController.services_screen);


module.exports = router

const express = require('express')
const ShippingAddressControlller = require('../controllers/ShippingAddress')
const router = express.Router();

router.get('/', ShippingAddressControlller.findAll);
router.get('/:id', ShippingAddressControlller.findOne);
router.post('/', ShippingAddressControlller.create);
router.patch('/:id', ShippingAddressControlller.update);
router.delete('/:id', ShippingAddressControlller.destroy);

module.exports = router

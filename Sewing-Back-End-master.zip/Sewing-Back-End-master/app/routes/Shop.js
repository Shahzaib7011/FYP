const express = require('express')
const ShopController = require('../controllers/Shop')
const router = express.Router();
router.get('/', ShopController.findAll);
router.get('/:id', ShopController.findOne);
router.post('/', ShopController.create);
router.patch('/:id', ShopController.update);
router.delete('/:id', ShopController.destroy);
module.exports = router
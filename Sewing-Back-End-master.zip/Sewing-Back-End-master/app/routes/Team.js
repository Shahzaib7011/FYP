const express = require('express')
const TeamController = require('../controllers/Team')
const router = express.Router();
router.get('/get_teams_info', TeamController.get_info);
module.exports = router
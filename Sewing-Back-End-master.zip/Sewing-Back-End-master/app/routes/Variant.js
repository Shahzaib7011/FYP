const express = require('express')
const VariantController = require('../controllers/Variant')
const router = express.Router();
router.get('/', VariantController.findAll);
router.get('/:id', VariantController.findOne);
router.post('/', VariantController.create);
router.patch('/:id', VariantController.update);
router.delete('/:id', VariantController.destroy);
module.exports = router
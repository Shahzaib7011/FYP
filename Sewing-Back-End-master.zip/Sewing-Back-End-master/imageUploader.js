const cloudinary = require('cloudinary').v2;
const fs = require('fs');


cloudinary.config({ 
  cloud_name: 'drrujfgnx', 
  api_key: '658967857327783', 
  api_secret: '3jF3eiHf8zoIS2F1xe3aYVIDeUs' 
});


const uploadImage = async (imagePath) => {

    console.log("Image uploaded Path", imagePath);

    // Use the uploaded file's name as the asset's public ID and 
    // allow overwriting the asset with new versions
    const options = {
      use_filename: true,
      unique_filename: false,
      overwrite: true,
    };

    try {
      const result = await cloudinary.uploader.upload(imagePath, options);
        console.log("Result from the cloudinary",result);
       // Delete local file after successful upload to Cloudinary
        fs.unlink(imagePath, (err) => {
            if (err) {
                console.error('Error deleting local file:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }
            console.log('Local file deleted successfully');
        });

      return result.secure_url;
    } catch (error) {
      console.log("Error from Cloundinary",error);
      console.error(error);
    }
};

module.exports = uploadImage;
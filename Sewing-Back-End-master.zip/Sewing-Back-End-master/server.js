const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');  // session middleware
const cors = require("cors");
let ejs = require('ejs');
const mongoose = require('mongoose');
const { format } = require('date-fns');
const OpenAI = require("openai").OpenAI;
const http = require('http');
const apiKey = 'sk-proj-EU7mKeokib0VBIeVMT4FT3BlbkFJxJpgRkA6P8pkGoRsTSoP';
const openai = new OpenAI({ apiKey: apiKey });
const socket = require("socket.io");
const dbConfig = require('./config/database.config.js');

mongoose.Promise = global.Promise;
mongoose.connect(dbConfig.url, {
    useNewUrlParser: true
}).then(() => {
    console.log("Database Connected Successfully!!");
}).catch(err => {
    console.log('Could not connect to the database', err);
    process.exit();
});

require('./admin_user.js');

const corsOptions = {
    origin: '*',
    credentials: true
};

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors(corsOptions));



// Routes
const UserRoute = require('./app/routes/User');
const FaqRoute = require('./app/routes/Faq');
const BillingAddressRoute = require('./app/routes/BillingAddress');
const ShippingAddressRoute = require('./app/routes/ShippingAddress');
const orderRoute = require('./app/routes/Order');
const LineItemRoute = require('./app/routes/LineItem');
const BrandRoute = require('./app/routes/Brand');
const ProductRoute = require('./app/routes/Product');
const ShopRoute = require('./app/routes/Shop');
const VariantRoute = require('./app/routes/Variant');
const CouponRoute = require('./app/routes/Coupon');
const TeamRoute = require('./app/routes/Team');
const ContactUsRoute = require('./app/routes/ContactUs');
const ServiceRoute = require('./app/routes/Service');
const FavRoute = require('./app/routes/Favourite');

const AdminUserRoute = require('./admin_user');
const AdminOrderRoute = require('./admin_order');
const AdminTestimonialRoute = require('./admin_testimonial');
const AdminProductRoute = require('./admin_product');
const AdminBillingAddressRoute = require('./admin_billing_address');
const AdminShippingAddressRoute = require('./admin_shipping_address');
const AdminTailorRoute = require('./admin_tailor');
const AdminCategoryRoute = require('./admin_category');
const AdminTeamRoute = require('./admin_team_route');
const AdminContactUsRoute = require("./admin_contact_us");
const AdminServiceRoute = require("./admin_service");
const AdminRoleRoute =  require("./admin_role");
const AdminFaqRoute = require("./admin_faq");
const AdminNotificationRoute = require("./admin_notification");

app.use('/user', UserRoute);
app.use('/faq', FaqRoute);
app.use('/billing_address', BillingAddressRoute);
app.use('/shipping_address', ShippingAddressRoute);
app.use('/order', orderRoute);
app.use('/line_item', LineItemRoute);
app.use('/brand', BrandRoute);
app.use('/product', ProductRoute);
app.use('/shop', ShopRoute);
app.use('/variant', VariantRoute);
app.use('/coupon', CouponRoute);
app.use('/organization', TeamRoute);
app.use('/contact_us', ContactUsRoute);
app.use('/service', ServiceRoute);
app.use('/teams', TeamRoute);
app.use('/fav_items', FavRoute);

app.set('view engine', 'ejs');
app.use(express.static('public'));

const stripe = require("stripe")("sk_test_51PDYcWGOjcUEBvYFxisEf8NLqqjeGn3a2QC4welZE3cgZnqcs1HguEfUGcNOoe5UJFkZOEsoCbqZOWG0qmuDfyIE00RHPVlTz2"); // <-- change the key here

app.post("/create-payment-intent", async (req, res) => {
    const { price } = req.body;
    console.log("Price ================>", price);
    if(!price) {
        return res.status(400).send({ error: "Price not provided" });
    }
    const paymentIntent = await stripe.paymentIntents.create({
        amount: price,
        currency: "usd"
    });

    res.send({
        clientSecret: paymentIntent.client_secret,
    });
});

const auth = require('./app/middleware/auth');
const UserModel = require("./app/model/user");
const OrderModal = require("./app/model/order");
const ProductModal = require("./app/model/product");
const LineItemModel = require("./app/model/line_item");
const ShippingAddressModal = require("./app/model/shipping_address");
const BillingAddressModal = require("./app/model/billing_address");
const TailorModel = require("./app/model/user");
const TeamModal = require("./app/model/team");
const TestimonialModel = require("./app/model/testimonial");
const FaqModal = require("./app/model/faq");
const RoleModal = require("./app/model/role");
const NotificationModal = require("./app/model/notification");
const authRoutes = require("./app/routes/auth.js");
const messageRoutes = require("./app/routes/messages.js");
app.get('/delete-product/:id',  async function(req, res){
    const id = req.params.id;
    console.log("Product ID ======>", id);
    await ProductModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/products')
        } else {
            const newNotification = new NotificationModal({ text: 'Product delete successfully ' });
            newNotification.save();
            res.redirect('/products')
        }
    }).catch(err => {
        res.redirect('/products')
    });
  });

  app.get('/delete-order/:id',auth.isLogin ,  async function(req, res){
    const id = req.params.id;
    try {
        const newNotification = new NotificationModal({ text: 'order delete successfully ' });
        newNotification.save();
        await LineItemModel.deleteMany({ order: id });
        await OrderModel.findByIdAndDelete(id);
        res.redirect('/orders')
    } catch (error) {
        res.redirect('/orders')
    }

});

app.get('/delete-user/:id',  async function(req, res){
    const id = req.params.id;
    console.log("USER ID ===========> ", id);
    await UserModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/users')
        } else {
            const newNotification = new NotificationModal({ text: 'User delete successfully ' });
            newNotification.save();
            res.redirect('/users')
        }
    }).catch(err => {
        res.redirect('/users')
    });
});

app.use("/api/auth", authRoutes);
app.use("/api/messages", messageRoutes);


app.get('/delete-billing-address/:id', async function(req,res){
    const id = req.params.id;
    await BillingAddressModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/bill-address')
        } else {
            const newNotification = new NotificationModal({ text: 'Address delete successfully ' });
            newNotification.save();
            res.redirect('/bill-address')
        }
    }).catch(err => {
        res.redirect('/bill-address')
    });                     
});

app.get('/delete-role/:id',  async function(req, res){
    const id = req.params.id;
    await RoleModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/roles')
        } else {
            const newNotification = new NotificationModal({ text: 'Role delete successfully ' });
            newNotification.save();
            res.redirect('/roles');
        }
    }).catch(err => {
        res.redirect('/roles')
    });
});

app.get('/delete-ship-address/:id',async function(req,res){
    const id = req.params.id;
    await ShippingAddressModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/ship_address')
        } else {
            const newNotification = new NotificationModal({ text: 'Address delete successfully ' });
            newNotification.save();
            res.redirect('/ship_address')
        }
    }).catch(err => {
        res.redirect('/ship_address')
    });                     
});



app.get('/delete-tailor/:id', async function(req, res){
    const id = req.params.id;
    await TailorModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/tailors')
        } else {
            const newNotification = new NotificationModal({ text: 'Tailor delete successfully ' });
            newNotification.save();
            res.redirect('/tailors')
        }
    }).catch(err => {
        res.redirect('/tailors')
    });
});

app.get('/delete-teams/:id' ,  async function(req, res){
    const id = req.params.id;
    console.log("Delete Teams ======> ", id);
    await TeamModal.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/teams')
        } else {
            const newNotification = new NotificationModal({ text: 'Team delete successfully ' });
            newNotification.save();
            res.redirect('/teams')
        }
    }).catch(err => {
        res.redirect('/teams')
    });
});

app.get('/delete-testimonial/:id', async function(req, res){
    const id = req.params.id;
    console.log("Delete testimonials ======>", id);
    await TestimonialModel.findOneAndDelete(id).then(data => {
        if (!data) {
            res.redirect('/testimonials')
        } else {
            const newNotification = new NotificationModal({ text: 'Testimonials delete successfully ' });
            newNotification.save();
            res.redirect('/testimonials')
        }
    }).catch(err => {
        res.redirect('/testimonials')
    });
});

app.get('/delete-faqs/:id', async function(req, res){
    const id = req.params.id;
    console.log("Delete Faq ======>", id);
    await FaqModal.findOneAndDelete(id).then(data => {
        if (!data) {
            const newNotification = new NotificationModal({ text: 'Faq delete successfully ' });
            newNotification.save();
            res.redirect('/faqs');
        } else {
            res.redirect('/faqs');
        }
    }).catch(err => {
        res.redirect('/faqs');
    });
});

 


const CategoryModal = require("./app/model/category.js");

app.get('/categories_page', async (req, res) => {
    try {
        const categories = await CategoryModal.find({});
        res.status(200).json({ categories: categories });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/single_categories_page/:id', async (req, res) => {
    try {
        const category = await CategoryModal.findById(req.params.id);
        const products = await ProductModal.find({ category: category.id });
        res.status(200).json({
            user: user,
            category: category,
            products: products,
        });
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
});


app.use(session({
    secret: 'r8q,+&1LM3)CD*zAGpx1xm{NeQhc;#',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 3600 * 3600 * 1000 }
}));

app.get('/', auth.isLogin, async (req, res) => {
    data = {
        full_name: req.session.full_name,
        image: req.session.image,
        role: req.session.role,
        notifications: await NotificationModal.find().sort({ createdAt: -1 }).limit(3)
    };
    const today = new Date(); // Get today's date
    const users = await UserModel.find({
        created_at: {
            $gte: new Date(today.getFullYear(), today.getMonth(), today.getDate()), // Today's start
            $lt: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1) // Tomorrow's start
        }
    });
    const orders = await OrderModal.find({
        created_at: {
            $gte: new Date(today.getFullYear(), today.getMonth(), today.getDate()), // Today's start
            $lt: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1) // Tomorrow's start
        }
    });

    const total_users = await UserModel.find({});
    const total_orders = await OrderModal.find({});
    const total = total_orders.map(order => order.order_total);
    const filteredData = total.filter(item => item !== '').map(item => parseInt(item, 10));
    const totalSum = filteredData.reduce((acc, curr) => acc + curr, 0);
    const recentOrders = await OrderModal.find({}).sort({ created_at: -1 }).limit(15);
    res.render("./home/index", { data: data, users: users, orders: orders, total_users: total_users, total_orders: total_orders, recentOrders: recentOrders, format: format, total: totalSum });
});

const AdminSessionController = require('./app/admin_controllers/session');
const user = require('./app/model/user');
app.get('/login', auth.isLogout, AdminSessionController.adminlogin);
app.post('/login', AdminSessionController.verifylogin);
app.get('/logout', auth.isLogin, AdminSessionController.logout);
app.get('/settings', auth.isLogin, AdminSessionController.settings);
app.post('/update_the_info', auth.isLogin, AdminSessionController.update_the_info);
app.post('/update_settings/:id', auth.isLogin, AdminSessionController.update_settings);

app.get('/signup', (req, res) => {
    res.render("./registration/sign_up");
});

app.get('/visual_look', auth.isLogin, async (req, res) => {
    const usersByDay = await UserModel.aggregate([
        {
            $group: {
                _id: { $dateToString: { format: "%d", date: "$created_at" } },
                count: { $sum: 1 }
            }
        },
        {
            $sort: { _id: 1 } // Sort by date
        }
    ]);

    const formattedResult = usersByDay.map(({ _id, count }) => ({ day: _id, count }));
    res.render("./graph/index", { users: formattedResult });
});

app.post("/chatbot", async (req, res) => {
    const { question } = req.body;
    const response = await openai.chat.completions.create({
        messages: [
            {
                role: "system",
                content: "You are a helpful assistant of e-commerce website.",
            },
            {
                role: "user",
                content: question,
            },
        ],
        model: "gpt-3.5-turbo",
        max_tokens: 300,
    });
    res.send(response.choices[0].message.content);
});

app.use(AdminRoleRoute);
app.use(AdminUserRoute);
app.use(AdminOrderRoute);
app.use(AdminTestimonialRoute);
app.use(AdminProductRoute);
app.use(AdminBillingAddressRoute);
app.use(AdminShippingAddressRoute);
app.use(AdminTailorRoute);
app.use(AdminCategoryRoute);
app.use(AdminTeamRoute);
app.use(AdminContactUsRoute);
app.use(AdminServiceRoute);
app.use(AdminFaqRoute);
app.use(AdminNotificationRoute);

const server = http.createServer(app);

const io = socket(server, {
  cors: {
    origin: "http://localhost:3000",
    credentials: true,
  },
});

global.onlineUsers = new Map();
io.on("connection", (socket) => {
  global.chatSocket = socket;
  socket.on("add-user", (userId) => {
    onlineUsers.set(userId, socket.id);
  });

  socket.on("send-msg", (data) => {
    const sendUserSocket = onlineUsers.get(data.to);
    if (sendUserSocket) {
      socket.to(sendUserSocket).emit("msg-recieve", data.msg);
    }
  });
});

app.get('*', (req, res) => {
    res.render('./blank/404', { data: '' });
});

server.listen(3002, () => {
    console.log("Server is listening on port 3002");
});


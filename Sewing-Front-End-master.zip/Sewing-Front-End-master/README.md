### Project Development GuideLines

1. Insall Node version 14 or above
2. create react app using command npx create-react-app projectname
3. install tailwind css

### Project Setup Guidelines

https://app.tuk.dev/listing/webapp/UI_element/avatar

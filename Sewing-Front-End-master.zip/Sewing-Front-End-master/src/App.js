import './App.css';
import  { BrowserRouter as Router, Route, Routes } from "react-router-dom" ;
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Home from './pages/Home/home';
import SignUp from './pages/Sign_Up/Sign_Up';
import SignIn from './pages/Sign_In/Sign_In';
import ForgotPassword from './pages/Forgot_Password/Forgot_Password';
import About from './pages/About/About';
import TermsAndCondition from './pages/TermsAndCondition/terms_and_condition';
import ContactUs from './pages/Contact_Us/Contact_Us';
import PrivacyPolicy from './pages/Privacy_Policy/privacy_policy';
import Faq from './pages/FAQ/faq';
import Product from './pages/Product/Product';
import Store from './pages/Store/Store';
import Team from './pages/Team/Team';
import Tailor from './pages/Tailor/Tailor';
import Cart from './pages/Cart/Cart';
import Services from './pages/Services/Services';
import ClientSignUp from './pages/Sign_Up/Client_Sign_Up';
import UserProfile from './pages/Profile/UserProfile';
import Categories from './pages/Categories/Categories';
import BestSeller from './pages/Product/BestSeller';
import Favourites from './pages/Product/Favourites';
import OrderSummary from './pages/Cart/OrderSummary';
import CategoryProduct from './pages/Categories/CategoryProduct';
import PaymentSuccess from './pages/payments/payment_success';
import PaymentFail from './pages/payments/payment_fail';
import ProductDetail from './pages/Product/ProductDetail';
// import Chat from './pages/FAQ/Chat';
import ChangePassword from './pages/Sign_Up/Change_Password';
import './assets/css/index.css';
import Payment from "./Payment";
import SetAvatar from "./pages/Chat/components/SetAvatar";
import Chat from "./pages/Chat/Chat";


function App() {

  return (
      <Router>
          <Routes>
            < Route path="/" element={<Home/>}/>
            < Route path="/sign_up" element={<SignUp/>}/>
            < Route path="/sign_in" element={<SignIn/>}/>
            < Route path="/faq" element={<Faq/>}/>
            < Route path="/forgot_password" element={<ForgotPassword/>}/>
            < Route path="/about" element={<About/>}/>
            < Route path="/termsandcondition" element={<TermsAndCondition/>}/>
            < Route path="/privacy_policy" element={<PrivacyPolicy/>}/>
            < Route path="/contact_us" element={<ContactUs/>}/>
            < Route path="/products" element={<Product/>}/>
            < Route path="/team" element={<Team/>}/>
            < Route path="/store" element={<Store/>}/>
            < Route path="/tailers" element={<Tailor/>}/>
            < Route path="/chat" element={<Chat/>}/>
            < Route path="/chat/:id" element={<Chat/>}/>
            < Route path="/cart" element={<Cart/>}/>
            < Route path="/services" element={<Services/>}/>
            < Route path="/client_sign_up" element={<ClientSignUp/>}/>
            < Route path="/categories" element={<Categories/>}/>
            < Route path="/categories/:id" element={<CategoryProduct/>}/>
            < Route path="/products/:id" element={<ProductDetail/>}/>
            < Route path="/favourites" element={<Favourites/>}/>
            <Route path="/payment" element={<Payment />} />
            <Route path="/success_payment" element={<PaymentSuccess />} />
            <Route path="/fail_payment" element={<PaymentFail />} />
            <Route path="/best_seller" element={<BestSeller />} />
            <Route path="/order_summary" element={<OrderSummary />} />
            <Route path="/profile" element={<UserProfile />} />
            <Route path="/change_password" element={<ChangePassword />} />
            <Route path="/setAvatar" element={<SetAvatar />} />
          </Routes>
          <ToastContainer />
      </Router>
  );
}

export default App;
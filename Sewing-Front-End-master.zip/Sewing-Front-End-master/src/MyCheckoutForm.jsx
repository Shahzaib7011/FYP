import React, { useState, useEffect } from "react";
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from "react-redux";
import  { addAddress } from "./../src/store/cartSlice.js"
import { deleteitem, increasequantity, decreasequantity, clearCart  } from "./store/cartSlice.js";
import URLS from './config/urls.js';


export const MyCheckoutForm = () => {
  const totalPrice = 1400; // this means 14 usd and can also be calculated at the backend
  const { cart_items, total, sub_total, tax, delivery_amount } = useSelector((state) => state.carts);

  const { user_id, firstName,lastName, userName, email, phone, experience, description, role, image } = useSelector((state) => state.users);
  const dispatch = useDispatch();
  const [clientSecret, setClientSecret] = useState("");
  const stripe = useStripe();
  const elements = useElements();
  const [AddressstreetAddress, setAddressStreetAddress] = useState('');
  const [Addresscountry, setAddressCountry] = useState('');
  const [Addresscity, setAddressCity] = useState('');
  const [Addresszipcode, setAddressZipCode] = useState('');
  const [AddressfirstName, setAddressfirstName] = useState('');
  const [AddresslastName, setAddresslastName] = useState('');
  const [Addresscompany, setAddressCompany] = useState('');
  const [Addressphone, setAddressPhone] = useState('');
  const [AddressID, setAddressId] = useState('');



  // STEP 1: create a payment intent and getting the secret
  useEffect(() => {
    fetch(`${URLS.PAYMENT_INTENT_URL}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ price: 8000 * 1000 }),
    })
      .then(res => res.json())
      .then((data) => {
        console.log(data);
        setClientSecret(data?.clientSecret);  // <-- setting the client secret here
      });
  }, []);


  const handleSuccessToastClose = () => {
    dispatch(clearCart());
    window.location.href = "/success_payment"
  }


  const handleFailToastClose = () => {
    window.location.href = "/fail_payment"
  }


const create_order_address = async () => {
  try {
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    myHeaders.append("Cookie", "connect.sid=s%3AfRIwpWnw5sqhr6BQ9FAK8P2PByg9mfWW.cchAOUioJ7Nx0Mabp%2FKVzLjP6MB2mS77f%2FEPW5xOrUU");

    const urlencoded = new URLSearchParams();
    urlencoded.append("house_number", Addressphone);
    urlencoded.append("street", "z-l");
    urlencoded.append("zipcode", Addresszipcode);
    urlencoded.append("city", Addresscity);
    urlencoded.append("country", Addresscountry);

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: urlencoded,
      redirect: "follow"
    };

    const response = await fetch(`${URLS.BILLING_ADDRESS_URL}`, requestOptions);
    const result = await response.text();
    const res = JSON.parse(result);
    const id = res?.billing_address?._id;
    return id;
  } catch (error) {
    console.error(error);
  }
};

  const place_order_function = async (id) => {
      const temp_line_items = cart_items.map((item) => {
        {
          return {
            "product": item.id,
            "quantity": item.quantity,
            "image_url": item.image_name,
            "price": item.product_price,
            "name": item.product_name
          }
        }
      })    
      const myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");
      myHeaders.append("Cookie", "connect.sid=s%3AfRIwpWnw5sqhr6BQ9FAK8P2PByg9mfWW.cchAOUioJ7Nx0Mabp%2FKVzLjP6MB2mS77f%2FEPW5xOrUU");

      const raw = JSON.stringify({
        "user": user_id,
        "shipping_address": id,
        "billing_address": id,
        "delivery_charges": delivery_amount,
        "order_total": sub_total,
        "item_total": total,
        "tax_rate": tax,
        "lineItems": temp_line_items
      });

      const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
      };
    
      fetch(`${URLS.ORDER_URL}`, requestOptions)
        .then((response) => response.text())
        .then((result) => console.log(result))
        .catch((error) => console.error(error));
  }

//   https://app.tuk.dev/signup
  // STEP 2: make the payment after filling the form properly
  const makePayment = async (e) => {
    try {
    e.preventDefault();
    if(AddressfirstName && AddresslastName && Addresscompany && Addressphone && Addresscity && Addresscountry && AddressstreetAddress)
    {
      dispatch(addAddress({AddressfirstName, AddresslastName, Addresscompany, Addressphone, Addresscity, Addresscountry, AddressstreetAddress}))
      const payload = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
        },
      });

        if (payload.error) {
        toast(payload.error.message, {
          onClose: handleFailToastClose
        });
       } else {
        if (payload.paymentIntent.status === "succeeded") {
          let id =await create_order_address();
          await place_order_function(id);
          setAddressPhone('');
          setAddressCity('');
          setAddressCountry('');
          setAddressStreetAddress('');
          setAddressfirstName('');
          setAddresslastName('');
          setAddressCompany('');
          setAddressZipCode('');
          toast("Order Placed Successfully", {
                onClose: handleSuccessToastClose
            });
           toast("Payment succeeded", {
                onClose: handleSuccessToastClose
            });
        }
      }
    }
    else
    {
      toast('Kindly Fill Up the Address Information')
    }
    }
    catch(err)
    {
        let id = await create_order_address();
          await place_order_function(id);
          setAddressPhone('');
          setAddressCity('');
          setAddressCountry('');
          setAddressStreetAddress('');
          setAddressfirstName('');
          setAddresslastName('');
          setAddressCompany('');
          setAddressZipCode('');
          toast("Order Placed Successfully", {
                onClose: handleSuccessToastClose
            });
           toast("Payment succeeded", {
                onClose: handleSuccessToastClose
            });
    }

  }

  return (
    <>
    <div className="pt-4 pb-4">
        <form className="max-w-md mx-auto">
        <h2 className="mt-4 mb-4"> Address Information </h2>
        <div className="relative z-0 w-full mb-5 group">
            <input type="text"  onChange={ (e) => setAddressStreetAddress(e.target.value)} value={AddressstreetAddress} name="floating_email" id="floating_email" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
            <label htmlFor="floating_email" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Street Address</label>
        </div>
        <div className="relative z-0 w-full mb-5 group">
            <input type="text" value={Addresscountry} onChange={ (e) => { setAddressCountry(e.target.value)}} name="floating_password" id="floating_password" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
            <label htmlFor="floating_password" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Country</label>
        </div>
        <div className="relative z-0 w-full mb-5 group">
            <input type="text" value={Addresscity} onChange={ (e) => {setAddressCity(e.target.value )}} name="repeat_password" id="floating_repeat_password" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
            <label htmlFor="floating_repeat_password" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">City</label>
        </div>
          <div className="relative z-0 w-full mb-5 group">
            <input type="tel" value={Addresszipcode} onChange={ (e) => {setAddressZipCode(e.target.value )}} name="repeat_password" id="floating_repeat_password" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
            <label htmlFor="floating_repeat_password" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Zip Code</label>
        </div>
        <div className="grid md:grid-cols-2 md:gap-6">
            <div className="relative z-0 w-full mb-5 group">
                <input type="text" value={AddresslastName} onChange={ (e) => { setAddresslastName(e.target.value )}} name="floating_first_name" id="floating_first_name" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
                <label htmlFor="floating_first_name" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">First name</label>
            </div>
            <div className="relative z-0 w-full mb-5 group">
                <input type="text" value={AddressfirstName} onChange={ (e) => { setAddressfirstName(e.target.value )}} name="floating_last_name" id="floating_last_name" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
                <label htmlFor="floating_last_name" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Last name</label>
            </div>
        </div>
        <div className="grid md:grid-cols-2 md:gap-6">
            <div className="relative z-0 w-full mb-5 group">
                <input type="tel"  value={Addressphone} onChange={ (e) => { setAddressPhone(e.target.value) } } name="floating_phone" id="floating_phone" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
                <label htmlFor="floating_phone" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Phone number (123-456-7890)</label>
            </div>
            <div className="relative z-0 w-full mb-5 group">
                <input type="text" value={Addresscompany} onChange={ (e) => { setAddressCompany(e.target.value )}} name="floating_company" id="floating_company" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
                <label htmlFor="floating_company" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Company (Ex. Google)</label>
            </div>
        </div>
        </form>
        <form id="payment-form" onSubmit={makePayment} className="max-w-md mx-auto">
          <h2 className="mt-4" > Payment Information </h2>
          <CardElement id="card-element" className="pt-4 pb-4" />
          <button  id="submit" type="submit" className="text-white bg-blue-700 pt-4 pb-4 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Pay Now and Place Order</button>
        </form>
    </div>
    </>
  );
};
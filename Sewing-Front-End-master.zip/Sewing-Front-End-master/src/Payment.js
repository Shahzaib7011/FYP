import React from "react";
import { MyCheckoutForm } from "./MyCheckoutForm";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import Layout from "./components/layout/Layout";



const Payment = () => {

  const stripePromise = loadStripe("pk_test_51PDYcWGOjcUEBvYFSPu3osdc4H6bm5Yg7ByEizDOefKdWA1uS6yT2Bvmhk12Lu6sI1Gg0H4EHTI1IGlzeW88Qh9900C2nYn5CZ");
    return (
      <Layout>
          <Elements stripe={stripePromise}>
                <MyCheckoutForm />
           </Elements>
        </Layout>
        )
 }

 export default Payment
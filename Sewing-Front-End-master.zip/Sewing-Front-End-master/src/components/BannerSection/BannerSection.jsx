
import React from 'react';
import { Banner } from 'flowbite-react';
import { FaBookOpen } from 'react-icons/fa';
import { HiArrowRight, HiX } from 'react-icons/hi';

const BannerSection = ({section_name, section_category, href_link}) => {
  return (
    <Banner className='py-12 px-4 primary_color text-white'>
      <div className="flex w-full flex-col justify-between border-b border-gray-200 bg-gray-50 p-4 dark:border-gray-600 dark:bg-gray-700 md:flex-row">
        <div className="mb-4 md:mb-0 md:mr-4">
          <h1 className="mb-1 text-base font-semibold text-lime-500 dark:text-white">{section_name}</h1>
          <p className="flex items-center text-sm font-normal text-gray-500 dark:text-gray-400">
              Discover top-notch sewing machines, kits, fabrics & more on our vibrant online sewing hub!
          </p>
        </div>
        <div className="flex flex-shrink-0 items-center">
          <a href="#"  className="mr-3 inline-flex items-center justify-center rounded-lg border font-medium primary_color text-white p-5">
            <FaBookOpen className="mr-2 h-4 w-4" />
            {section_category}
          </a>
          <a href={href_link} className="mr-2 inline-flex items-center justify-center rounded-lg bg-lime-500 text-white hover:bg-emerald-700 hover:text-white p-5" >
            See All  
             <HiArrowRight className="ml-2 h-4 w-4" />
          </a>
        </div>
      </div>
    </Banner>
  );
}

export default BannerSection

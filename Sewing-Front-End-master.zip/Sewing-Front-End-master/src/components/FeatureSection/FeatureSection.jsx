import React from "react";
import ProductCart from "../productCart/ProductCart";
import { additem  } from "../../store/cartSlice";
import { addToFavour } from '../../store/favouriteSlice';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from "react-redux";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

const FeatureSection = ({products}) => {
  const dispatch = useDispatch();
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 5
    },
    desktop: {
      breakpoint: { max: 8000, min: 1024 },
      items: 5
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };
  const { firstName, lastName, userName, email, phone_number,  image, expereince, login} = useSelector((state) => state.users);
     const handleadditem = (key, image_name, product_name, product_description, product_price) => {
      if(!email)
      {
        toast("Login first Before adding the product in cart", { type: "failure" });
        return;
      }
      dispatch(additem({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Cart", { type: "success" });
    }

    const handlefavItem = (key, image_name, product_name, product_description, product_price) => {
      if(!email)
      {
        toast("Login first Before adding into favourites", { type: "failure" });
        return;
      }
      dispatch(addToFavour({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Favourite", { type: "success" });
    }

    return (
           <Carousel responsive={responsive}>
            {
                products.map((product) => {
                   const shortenedText = product.description.length > 100 ? product.description.substring(0, 100) + '...' : product.description
                    return (
                      <ProductCart product_id={product._id} image_name={product.image_url} product_name={product.title} product_description={shortenedText} product_price={product.list_price.$numberDecimal} handleadditem={handleadditem}  handlefavItem={handlefavItem}/>
                    )
                })
            }
          </Carousel>
    )

}

export default FeatureSection
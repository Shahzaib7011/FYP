import React from "react";
import { useSelector, useDispatch } from "react-redux";
import TailerProfileCard from "../TailerProfileCard/TailerProfileCard";

const FeatureTailer = ({tailors}) =>  {
    const { firstName, lastName, userName, email, phone_number,  image, expereince, login} = useSelector((state) => state.users);
    return (
        <div className="grid sm:grid-cols-3 gird-cols-1">
            {
        tailors.map((tailor) =>{
            return (
                <TailerProfileCard id={tailor._id} username={tailor.username} image_url={tailor.image_url} email={tailor.email}  login={login} admin_email={email} admin_username={userName}/>
            )
        })
        }
        </div>
 
    )
}

export default FeatureTailer;
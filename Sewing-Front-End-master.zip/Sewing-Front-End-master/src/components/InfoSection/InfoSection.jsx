// https://github.com/chrisblakely01/react-redux-todo-app.git
import React from "react";
import { Accordion } from 'flowbite-react';

const InfoSection = ({id,tag_line,answer,question}) => {
  return (
    <Accordion key={id} className="mt-2 mb-2 ">
      <Accordion.Panel className="">
        <Accordion.Title>{question}</Accordion.Title>
        <Accordion.Content>
          <p className="mb-2 text-gray-500 dark:text-gray-400">
            {tag_line}
          </p>
          <p className="text-gray-500 dark:text-gray-400">
             {answer}
          </p>
        </Accordion.Content>
      </Accordion.Panel>
    </Accordion>
  );
}

export default InfoSection;

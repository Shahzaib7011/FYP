import React from 'react';
import { Tabs } from 'flowbite-react';
import { HiAdjustments, HiClipboardList, HiUserCircle } from 'react-icons/hi';
import { MdDashboard } from 'react-icons/md';

const TabSection = () => {
  return (
      <div className=''>
        <h1 className='justify-content-center'>How It Works</h1>
      <Tabs aria-label="Tabs with icons" style="underline">
        <Tabs.Item active title="Sign Up" icon={HiUserCircle}>
         Create Account on Sui Dhaga
        </Tabs.Item>
        <Tabs.Item title="Add to Cart" icon={MdDashboard}>
          Look for the Products on Sui Dhaga and add them to cart
        </Tabs.Item>
        <Tabs.Item title="Check Out" icon={HiAdjustments}>
           Fill up the delivery information and give card details 
        </Tabs.Item>
        <Tabs.Item title="Place Order" icon={HiClipboardList}>
          Once you review your order Place it on Sui Dhaga
        </Tabs.Item>
      </Tabs>
    </div>
  );
}


export default TabSection
import React from 'react';

const TailerProfileCard = ({ id, username , image_url, email, lastName, firstName, phone, created_at, experience , login, admin_email, admin_username }) => {
  return (
   <div className="m-10 max-w-sm" key={id}>
      <div className="rounded-lg border custom_bg_color px-4 pt-8 pb-10 shadow-lg">
    <div className="relative mx-auto w-100 rounded-full">
      <span className="absolute right-0 m-3 h-3 w-3 rounded-full bg-green-500 ring-2 ring-green-300 ring-offset-2"></span>
      <img className="mx-auto h-auto w-full rounded-full" src={image_url} alt="" />
    </div>
    <h1 className="my-1 text-center text-xl font-bold leading-8 text-gray-900">{username}</h1>
    <h3 className="font-lg text-semibold text-center leading-6 text-gray-600">{firstName} {lastName}</h3>
    <p className="text-center text-sm leading-6 text-gray-500 hover:text-gray-600">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Architecto, placeat!</p>
    <ul className="mt-3 divide-y rounded bg-gray-100 py-2 px-3 text-gray-600 shadow-sm hover:text-gray-700 hover:shadow">
      <li className="flex items-center py-3 text-sm primary_color text-white p-2">
        <span className='primary_color text-white'>Status</span>
        <span className="ml-auto"><span className="rounded-full bg-green-200 py-1 px-2 text-xs font-medium text-green-700">Open for Work</span></span>
      </li>
      <li className="flex items-center py-3 text-sm primary_color text-white p-2">
        <span className='primary_color text-white'>Joined On</span>
        <span className="ml-auto">{created_at}</span>
      </li>
        <li className="flex items-center py-3 text-sm primary_color text-white p-2">
        <span className=''>Phone Number</span>
        <span className="ml-auto">{phone}</span>
      </li>
        <li className="flex items-center py-3 text-sm primary_color text-white p-2">
        <span className='primary_color text-white'>Email</span>
        <span className="ml-auto">{email}</span>
      </li>
      <li className="flex items-center py-3 text-sm primary_color text-white p-2 justify-center">
        {
          login && (
            <a href={`/chat/${id}`} >
              <button className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>Chat With Tailor</button>
            </a>
          ) 
           ||
             !login && (
             <a href='/sign_in' >
              <button className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>Sign in first to Chat With Tailor</button>
            </a>
          )
        }
        
      </li>
    </ul>
  </div>
</div>
  );
}


export default TailerProfileCard
import React from "react";
import { Carousel } from 'flowbite-react';

const CarouselSection = ({ProductimageUrls}) => {
  const filteredArray = ProductimageUrls && ProductimageUrls.length ? ProductimageUrls.filter(item => item !== null) : [];
  console.log(filteredArray);
  return (
    <div className="h-56 sm:h-64 xl:h-80 2xl:h-96">
      <Carousel>
        {
          filteredArray.map((item) => {
            return (
              <img src={item} alt="..." key={item}  className="object-center object-cover"/>
            )
          })
        }
      </Carousel>
    </div>
  );
}


export default CarouselSection
import React from "react";
import { Footer } from 'flowbite-react';
import { BsDribbble, BsFacebook, BsGithub, BsInstagram, BsTwitter } from 'react-icons/bs';
import  MainLogo from "../../assets/images/logo.jpg";

const FooterSection = () => {
  return (
    <Footer container className="py-12 px-4 primary_color text-white">
      <div className="w-full">
        <div className="grid w-full justify-between sm:flex sm:justify-between md:flex md:grid-cols-2">
          <div className="primary_color text-white">
            <Footer.Brand
              href="/"
              src={MainLogo}
              alt="Sui Dhagha"
              name="Sui Dhagha"
              className="text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-8 sm:mt-4 sm:grid-cols-3 sm:gap-6 primary_color text-white">
            <div className="primary_color hover:text-white">
              <Footer.Title title="about" className="primary_color" />
              <Footer.LinkGroup col className="primary_color">
                <Footer.Link href={'/faq'}>FAQ's</Footer.Link>
                <Footer.Link href={'/about'}>About US</Footer.Link>
              </Footer.LinkGroup>
            </div>
            <div>
              <Footer.Title title="Services" className="primary_color text-white" />
              <Footer.LinkGroup col className="primary_color p-5">
                <Footer.Link href={'/products'}>Products</Footer.Link>
                <Footer.Link href={'/tailers'}>Tailers</Footer.Link>
              </Footer.LinkGroup>
            </div>
            <div>
              <Footer.Title title="Legal"  className="primary_color text-white"/>
              <Footer.LinkGroup col className="hover primary_color">
                <Footer.Link href={'/privacy_policy'}>Privacy Policy</Footer.Link>
                <Footer.Link href={'/termsandcondition'}>Terms &amp; Conditions</Footer.Link>
              </Footer.LinkGroup>
            </div>
          </div>
        </div>
        <Footer.Divider />
        <div className="w-full sm:flex sm:items-center sm:justify-between primary_color text-white"> 
          <Footer.Copyright href="#" by="Sui Dhagha"  className="text-white" year={2024} />
          <div className="mt-4 flex space-x-6 sm:mt-0 sm:justify-center">
            <Footer.Icon href="/" className="text-white" icon={BsFacebook} />
            <Footer.Icon href="/" className="text-white" icon={BsInstagram} />
            <Footer.Icon href="/" className="text-white" icon={BsTwitter} />
            <Footer.Icon href="/" className="text-white" icon={BsGithub} />
            <Footer.Icon href="/" className="text-white"icon={BsDribbble} />
          </div>
        </div>
      </div>
    </Footer>
  );
}


export default FooterSection
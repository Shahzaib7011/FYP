import React from 'react';

const FooterButton = () => {
  return (
    <div className="flex justify-center">
        <a href='/chat' className="justify-content-center">
           <button type="button" className='custom_primary_color' >
             Button
            </button>
        </a>
    </div>
  );
}

export default FooterButton;
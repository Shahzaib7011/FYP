import React from "react";
import Header from "../header/Header";
import FooterSection from "../footer/Footer";
import FooterButton from "../footer/FooterButton";

const Layout = ({children}) => {
  
    return (
        <div className="">
            <Header/>
             <div>
                 {children}
            </div>
            <FooterButton/>
            <FooterSection/>
        </div>
    )
}

export default Layout
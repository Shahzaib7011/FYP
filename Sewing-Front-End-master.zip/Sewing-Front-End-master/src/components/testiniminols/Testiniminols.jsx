import React from "react";
import { Avatar, Blockquote } from 'flowbite-react';

const Testiniminols = ({ id, user_image, user_position, user_name, user_comment }) => {
  return (
      <blockquote className="relative bg-white p-5 border border-gray-200 break-inside-avoid-column m-10 text-white custom_bg_color" key={id}>
        <h2 className="text-sm custom_text_color">“{user_comment}“</h2>
        <div className="mt-5 flex items-start gap-4">
            <img src={user_image} className="w-10 h-10 object-cover object-center custom_text_color" alt="Aaron Francis"/>
            <div className="text-xs">
                <cite className="not-italic custom_text_color">{user_name},{user_position}</cite>
                <p className="text-gray-700 custom_text_color">Worked at <a href="" target="_blank" className="text-red-500">{user_position}</a></p>
            </div>
        </div>
      </blockquote>
  );
}

export default Testiniminols

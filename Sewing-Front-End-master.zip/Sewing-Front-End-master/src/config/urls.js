const SERVER_BASE_URL = 'http://44.217.212.115:3002'; 
const BASE_URL = 'http://localhost:3002'


const URLS = {
  BASE_URL: BASE_URL,
  SOCKET_IO_SERVER: 'http://localhost:3002',
  SIGN_UP_URL: `${BASE_URL}/signup`,
  LOGIN_URL: `${BASE_URL}/login`,
  TAILOR_URL: `${BASE_URL}/user/tailors_info`,
  HOME_URL: `${BASE_URL}/product/home_page/`,
  PRODUCT_URL: `${BASE_URL}/product/`,
  TEAM_URL: `${BASE_URL}/teams/get_teams_info`,
  FAQ_URL: `${BASE_URL}/faq/`,
  CATEGORY_URL: `${BASE_URL}/categories_page`,
  USER_SIGN_UP: `${BASE_URL}/user/`,
  USER_LOGIN_IN_URL: `${BASE_URL}/user/user_login`,
  CONTACT_US: `${BASE_URL}/contact_us`,
  CHATBOT: `${BASE_URL}/chatbot`,
  PAYMENT_INTENT_URL: `${BASE_URL}/create-payment-intent`,
  BILLING_ADDRESS_URL: `${BASE_URL}/billing_address/`,
  ORDER_URL: `${BASE_URL}/order/`,
  BEST_SELLER_URL: `${BASE_URL}/product/`,
  SPECIFIC_CATEGORY_URL: `${BASE_URL}/single_categories_page`,
  SET_AVATAR_URL: `${BASE_URL}/api/auth/setavatar`,
  SEND_MESSAGE_URL: `${BASE_URL}/api/messages/addmsg`,
  RECIEVE_MESSAGE_URL: `${BASE_URL}/api/messages/getmsg`,
  CHAT_ALL_USER_URL: `${BASE_URL}/api/auth/allusers`,
  logoutRoute: `${BASE_URL}/api/auth/logout`,
  ORDER_SUMMARY_URL: `${BASE_URL}/order/`
};

export default URLS;

// export const host = "http://localhost:5000";
// export const loginRoute = `${host}/api/auth/login`;
// export const registerRoute = `${host}/api/auth/register`;
// export const logoutRoute = `${host}/api/auth/logout`;
// export const allUsersRoute = `${host}/api/auth/allusers`;
// export const sendMessageRoute = `${host}/api/messages/addmsg`;
// export const recieveMessageRoute = `${host}/api/messages/getmsg`;
// export const setAvatarRoute = `${host}/api/auth/setavatar`;
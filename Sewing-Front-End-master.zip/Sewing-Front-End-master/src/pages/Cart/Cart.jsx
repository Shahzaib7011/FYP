import React from "react";
import Layout from "../../components/layout/Layout";
import { useSelector, useDispatch } from "react-redux";
import { deleteitem, increasequantity, decreasequantity, clearCart  } from "../../store/cartSlice";
import { toast } from 'react-toastify';

const Cart = () => {
  
  const { cart_items, total, sub_total, tax, delivery_amount } = useSelector((state) => state.carts);
     const dispatch = useDispatch();

  const handleClearCart = () => {
    dispatch(clearCart());
  }

  const handlePlusQuantuty = (product_id) => {
    dispatch(increasequantity(product_id))
  }

  const handleRemoveItem = (product_id) => {
      dispatch(deleteitem(product_id))
      toast("Item Removed", { type: "success" });
  }

  const handleMinusQuantuty = (product_id) => {
    console.log(product_id);
    dispatch(decreasequantity(product_id))
  }


    return (
        <Layout>
            <div className="bg-gray-100 h-screen py-8">
            <div className="container mx-auto px-4">
                <h1 className="text-2xl font-semibold mb-4">Shopping Cart</h1>
                <p className="text-2xl font-semibold mb-4"><a onClick={handleClearCart}>Clear Cart</a></p>
                <div className="flex flex-col md:flex-row gap-4">
                    <div className="md:w-3/4">
                        <div className="bg-white rounded-lg shadow-md p-6 mb-4">
                            <table className="w-full">
                                <thead>
                                    <tr>
                                        <th className="text-left font-semibold">Product</th>
                                        <th className="text-left font-semibold">Price</th>
                                        <th className="text-left font-semibold">Quantity</th>
                                        <th className="text-left font-semibold">Total</th>
                                        <th className="text-left font-semibold">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     {
                                            cart_items.map((product) =>{
                                                console.log(product)
                                                return (

                                                    <tr>
                                                        <td className="py-4" key={product.id}>
                                                            <div className="flex items-center">
                                                                <img className="h-16 w-16 mr-4" src={product.image_name} alt="Product image"/>
                                                                <span className="font-semibold">{product.product_name}</span>
                                                            </div>
                                                        </td>
                                                        <td className="py-4">${product.product_price}</td>
                                                        <td className="py-4">
                                                            <div className="flex items-center">
                                                                <button className="border rounded-md py-2 px-4 mr-2" onClick={ () => { handleMinusQuantuty(product.id) }}>-</button>
                                                                <span className="text-center w-8">{product.quantity}</span>
                                                                <button className="border rounded-md py-2 px-4 ml-2" onClick={ () => { handlePlusQuantuty(product.id)} }>+</button>
                                                            </div>
                                                        </td>
                                                        <td className="py-4">$ {product.product_price * product.quantity }</td>
                                                        <td className="py-4"><a className="focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-800 text-base leading-none text-red-600 hover:text-red-800" onClick={ () => { handleRemoveItem(product.id)}}>Remove</a></td>
                                                    </tr>

                                                )
                                            })
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="md:w-1/4">
                        <div className="bg-white rounded-lg shadow-md p-6">
                            <h2 className="text-lg font-semibold mb-4">Summary</h2>
                            <div className="flex justify-between mb-2">
                                <span>Subtotal</span>
                                <span>${sub_total?.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between mb-2">
                                <span>Taxes</span>
                                <span>${tax?.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between mb-2">
                                <span>Shipping</span>
                                <span>${delivery_amount?.toFixed(2)}</span>
                            </div>
                            <hr className="my-2"/>
                            <div className="flex justify-between mb-2">
                                <span className="font-semibold">Total</span>
                                <span className="font-semibold">${total?.toFixed(2)}</span>
                            </div>
                            <button className="bg-blue-500 text-white py-2 px-4 rounded-lg mt-4 w-full">
                                <a href="/payment">Checkout</a></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        </Layout>
    )
}

export default Cart;
import React,  { useEffect, useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import Layout from "../../components/layout/Layout";
import { getCategorySync } from '../../store/categorySlice';


const Categories = () => {
    const { category } = useSelector((state) => state.category);  
    const dispatch = useDispatch();

    useEffect(() => {
      dispatch(getCategorySync())
    },[])

    return (
        <Layout>
        <div className="pb-16 bg-gray-100">
            <div className="flex justify-center items-center">
                <div className="2xl:mx-auto 2xl:container py-12 px-4 sm:px-6 xl:px-20 2xl:px-0 w-full">
                    <div className="flex flex-col jusitfy-center items-center space-y-10">
                        <div className="flex flex-col justify-center items-center space-y-2">
                            <p className="text-xl leading-5 text-gray-600">2024 Trend Categories</p>
                            <h1 className="text-3xl xl:text-4xl font-semibold leading-7 xl:leading-9 text-gray-800">Shop By Category</h1>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 md:gap-x-4 md:gap-x-8 w-full">
                           {
                               category.map((item) =>{
                                return (
                                    <div className="flex flex-col space-y-4 md:space-y-8 mt-4 md:mt-0 mb-4 border-teal-700	" key={item._id}>
                                        <div className="relative group flex justify-center items-center h-full w-full">
                                            <img className="object-center object-cover h-full w-full" src={item.image_url} alt="shoe-image" />
                                             <a href={`/categories/${item._id}`} className='focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 bottom-4 z-10 absolute text-base font-medium leading-none text-gray-800 py-3 w-36 nav_items_color_bg text-white'>
                                             <button className="focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 bottom-4 z-10 absolute text-base font-medium leading-none text-gray-800 py-3 w-36 nav_items_color_bg text-white">{item.title}</button>
                                            </a>
                                        </div>
                                    </div>

                                )
                              })
                            
                           }
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </Layout>
    )

}

export default Categories;
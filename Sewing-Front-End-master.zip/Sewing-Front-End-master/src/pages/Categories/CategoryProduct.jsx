import React,  { useEffect, useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import Layout from "../../components/layout/Layout";
import { useParams } from 'react-router-dom'; // Import useParams hook
import { getSpecificCategorySync } from '../../store/categorySlice';
import { additem } from "../../store/cartSlice";
import { toast } from 'react-toastify';


const  CategoryProduct = () => {
    const { id } = useParams(); 
    const {  specific_category, specific_category_list } = useSelector((state) => state.category);  
    const dispatch = useDispatch();


    useEffect(() => {
      dispatch(getSpecificCategorySync(id))
    },[])

    const handleadditem = (key, image_name, product_name, product_description, product_price) => {
      dispatch(additem({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Cart", { type: "success" });
    }


    return (
        <Layout>
        <div className=" 2xl:container 2xl:mx-auto">
            <div className=" bg-gray-50 text-center lg:py-10 md:py-8 py-6">
                <p className=" w-10/12 mx-auto md:w-full  font-semibold lg:text-4xl text-3xl lg:leading-9 md:leading-7 leading-9 text-center text-gray-800">{specific_category.title}</p>
            </div>
            <div className=" py-6 lg:px-20 md:px-6 px-4">
                <p className=" font-normal text-sm leading-3 text-gray-600 ">Home / Shop by Category / {specific_category.title}</p>
                <hr className=" w-full bg-gray-200 my-6" />

                <div className=" flex justify-between items-center">
                    <div className=" flex space-x-3 justify-center items-center">
                        <svg className=" cursor-pointer" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.75 7.5H20.25" stroke="#1F2937" strokeMiterlimit="10" strokeLinecap="round" />
                            <path d="M3.75 12H20.25" stroke="#1F2937" strokeMiterlimit="10" strokeLinecap="round" />
                            <path d="M3.75 16.5H20.25" stroke="#1F2937" strokeMiterlimit="10" strokeLinecap="round" />
                        </svg>
                        {/* <p className=" font-normal text-base leading-4 text-gray-800">Filter</p> */}
                    </div>
                    <p className=" cursor-pointer hover:underline duration-100 font-normal text-base leading-4 text-gray-600">Showing {specific_category_list.length} products</p>
                </div>

                <div className=" grid lg:grid-cols-4 sm:grid-cols-2 grid-cols-1 lg:gap-y-12 lg:gap-x-8 sm:gap-y-10 sm:gap-x-6 gap-y-6 lg:mt-12 mt-10">

                   {
                    specific_category_list.map((product) => {
                     const shortenedText = product.description.length > 100 ? product.description.substring(0, 100) + '...' : product.description
                        return (
                        <div className=" relative" key={product._id}>
                            <div className=" absolute top-0 left-0 py-2 px-4 bg-white bg-opacity-50 ">
                                <p className="text-xs leading-3 text-gray-800">{product.title}</p>
                            </div>
                            <div className=" relative group">
                                <div className=" flex justify-center items-center opacity-0 bg-gradient-to-t from-gray-800 via-gray-800 to-opacity-30 group-hover:opacity-50 absolute top-0 left-0 h-full w-full"></div>
                                <img className=" w-full" src={product.image_url} alt="A girl Posing " />
                                <div className=" absolute bottom-0 p-8 w-full opacity-0 group-hover:opacity-100">
                                    <button className=" font-medium text-base leading-4 text-gray-800 bg-white py-3 w-full"  onClick={ () => { handleadditem(product._id, product.image_name,product.product_name, product.product_description, product.product_price)}} >Add to Cart</button>
                                    <button className="bg-transparent font-medium text-base leading-4 border-2 border-white py-3 w-full mt-2 text-white">
                                        <a href={`/products/${product._id}`}>View Details</a></button>
                                </div>
                            </div>
                            <p className=" font-normal text-xl leading-5 text-gray-800 md:mt-6 mt-4">{shortenedText}</p>
                            <p className=" font-semibold text-xl leading-5 text-gray-800 mt-4">${product.list_price.$numberDecimal}</p>
                            <p className=" font-normal text-base leading-4 text-gray-600 mt-4">Stock {product.stock}</p>
                        </div>
                        )
                    })
                   }
 
                </div>
            </div>
        </div>
        </Layout>
    );
};

export default CategoryProduct;

import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { io } from "socket.io-client";
import styled from "styled-components";
import URLS from "../../config/urls";
import ChatContainer from "./components/ChatContainer";
import Contacts from "./components/Contacts";
import Welcome from "./components/Welcome";

export default function Chat() {
  const navigate = useNavigate();
  const socket = useRef();
  const [contacts, setContacts] = useState([]);
  const [currentChat, setCurrentChat] = useState(undefined);
  const [currentUser, setCurrentUser] = useState(undefined);

  // Fetch current user and navigate to sign-in if not found
  useEffect(() => {
    async function fetchCurrentUser() {
      if (!localStorage.getItem('chat-app-current-user')) {
        navigate("/sign_in");
      } else {
        const user = JSON.parse(localStorage.getItem('chat-app-current-user'));
        setCurrentUser(user);
      }
    }

    fetchCurrentUser();
  }, [navigate]);

  // Setup socket connection and add user
  useEffect(() => {
    if (currentUser) {
      socket.current = io(URLS.SOCKET_IO_SERVER);
      socket.current.emit("add-user", currentUser._id);

      return () => {
        socket.current.disconnect(); // Cleanup socket connection
      };
    }
  }, [currentUser]);

  // Fetch contacts if the user has an avatar image set
  useEffect(() => {
    async function fetchContacts() {
      if (currentUser) {
        if (currentUser.isAvatarImageSet) {
          const { data } = await axios.get(`${URLS.CHAT_ALL_USER_URL}/${currentUser._id}`);
          setContacts(data);
        } else {
          navigate("/setAvatar");
        }
      }
    }

    fetchContacts();
  }, [currentUser, navigate]);

  const handleChatChange = (chat) => {
    setCurrentChat(chat);
  };

  return (
    <Container>
      <div className="container">
        <Contacts contacts={contacts} changeChat={handleChatChange} />
        {currentChat === undefined ? (
          <Welcome />
        ) : (
          <ChatContainer currentChat={currentChat} socket={socket} />
        )}
      </div>
    </Container>
  );
}

const Container = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1rem;
  align-items: center;
  background-color: #131324;
  .container {
    height: 85vh;
    width: 85vw;
    background-color: #00000076;
    display: grid;
    grid-template-columns: 25% 75%;
    @media screen and (min-width: 720px) and (max-width: 1080px) {
      grid-template-columns: 35% 65%;
    }
  }
`;

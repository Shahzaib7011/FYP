// https://www.youtube.com/watch?v=fiesH6WU63I

import React,  { useEffect, useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import { addFaq  } from "../../store/faqSlice";
import { getFaqAsyc } from '../../store/faqSlice';

import Layout from '../../components/layout/Layout';
import InfoSection from "../../components/InfoSection/InfoSection";


const Faq = () => {

  const dispatch = useDispatch();
  const faqs = useSelector((state) => state.faqs);

  useEffect(() => {
    dispatch(getFaqAsyc())
  },[])

    return (
        <Layout className="">
            <div className='place-content-center nav_items_color_bg'>
                <h1 className='text-5xl font-bold mx-auto text-center pt-4 pb-4 text-white'> Frequently Asked Questions</h1>
            </div>
            {
                faqs.map((faq) =>{
                    return (
                     <InfoSection id={faq._id} tag_line={faq.tag_line} question={faq.question} answer={faq.answer} />
                    )
                })
            }
        </Layout>
    )

}

export default Faq
import Layout from "../../components/layout/Layout";
import Testiniminols from "../../components/testiniminols/Testiniminols";
import Pagination from "../../components/pagination/pagination";
import TimeLineSection from "../../components/timeline/timeline";
import ActivityLog from "../../components/activity_log/activity_log";
import CarouselSection from "../../components/carousel/carousel";
import ProductSlider from "../../components/product_slider/product_slider";
import BannerSection from "../../components/BannerSection/BannerSection";
import TabSection from "../../components/TabSection/TabSection";
import TableSection from "../../components/TableSection/TableSection";
import FeatureSection from "../../components/FeatureSection/FeatureSection";
import FeatureTailer from "../../components/FeatureSection/FeatureTailer";
import React,  { useEffect, useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import { getHomeAsync } from '../../store/homeSlice';
import { addProduct  } from "../../store/homeSlice";
import HeroSection from "../../components/heroSection/HeroSection";
import HappyCustomer from "../../components/heroSection/HappyCustomer";

const Home = () => {


  const dispatch = useDispatch();

  const { ProductimageUrls, products, tailors, tailorsUrls, testimonials } = useSelector((state) => state.home); 
  const { firstName, lastName, userName, email, phone_number,  image, expereince, login} = useSelector((state) => state.users);

  
  useEffect(() => {
    dispatch(getHomeAsync())
  },[])

    return (
        <Layout>
             

             <HeroSection email={email}/>
             <BannerSection section_name={"Popular Products"} section_category={"See More Popular Products"} href_link={'/store'} />
             <FeatureSection products={products} />
             <BannerSection section_name={"Popular Tailers"}  section_category={"See More Popular Tailors"} href_link={'/tailors'}/>
             <FeatureTailer tailors={tailors}/>      
             <HappyCustomer/>
             <BannerSection section_name={"Testimonials"} section_category={"See Top Testimonials"} href_link={'/store'}/>
            <div className="bg-white w-full px-4 pt-16 pb-16 bg-blue-500 text-white custom_bg_color" id="faq">
              <h2 className="text-4xl font-bold text-center text-white">TESTIMONIALS</h2>
              <p className="text-center">Subscribe Easy Tutorials YouTube channel to watch more videos.</p>
              <div className="flex justify-center mt-8">
                {
                  testimonials.map((testimonial) => {
                    return (
                      <div key={testimonial._id} className="bg-white text-black m-4 p-6 rounded-lg shadow-md max-w-sm">
                        <div className="flex justify-center mb-4">
                          <img src={testimonial.image_url} alt={testimonial.name} className="rounded-full w-24 h-24"/>
                        </div>
                        <p className="text-center mb-4">"{testimonial.comment}"</p>
                        <p className="text-center font-bold">{testimonial.name}</p>
                        <p className="text-center text-gray-600">{testimonial.position}</p>
                      </div>
                    );
                  })
                }
              </div>
            </div>

        </Layout>
    )
}


export  default Home
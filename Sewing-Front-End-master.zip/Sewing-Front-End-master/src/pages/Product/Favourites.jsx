import React, { useEffect, useState, useRef } from "react";
import Layout from "../../components/layout/Layout";
import { useSelector, useDispatch } from "react-redux";
import { toast } from 'react-toastify';
import { clearFavourite, removeToFavour } from "../../store/favouriteSlice";
import { useNavigate } from "react-router-dom";


export default function Favourites() {
    const navigate = useNavigate();
    const [currentUser, setCurrentUser] = useState(undefined);


      // Fetch current user and navigate to sign-in if not found
  useEffect(() => {
    async function fetchCurrentUser() {
      if (!localStorage.getItem('chat-app-current-user')) {
        navigate("/sign_in");
      } else {
        const user = JSON.parse(localStorage.getItem('chat-app-current-user'));
        setCurrentUser(user);
      }
    }

    fetchCurrentUser();
  }, [navigate]);

    const { fav_items } = useSelector((state) => state.favourites);
    const dispatch = useDispatch();


    const handleRemoveItem = (product_id) => {
       dispatch(removeToFavour(product_id))
    }

    return (
        <Layout>
        <div className="py-12">
            {/* Desktop Responsive Start */}
            <div className="hidden sm:flex flex-col justify-start items-start">
                <div className="pl-4 lg:px-10 2xl:px-20 flex flex-row justify-center items-end space-x-4">
                    <h1 className="text-4xl font-semibold leading-9 text-gray-800">Favourites</h1>
                    <p className="text-base leading-4 text-gray-600 pb-1">({fav_items.length}) Items</p>
                </div>
                <table className="w-full mt-16 whitespace-nowrap">
                    <thead aria-label="table heading" className="w-full h-16 text-left py-6 bg-gray-50 border-gray-200 border-b ">
                        <tr>
                            <th className="text-base font-medium leading-4 text-gray-600 pl-3">YOUR PRODUCT</th>
                            <th className="text-base font-medium leading-4 text-gray-600 pl-3">DESCRIPTION</th>
                            <th className="text-base font-medium leading-4 text-gray-600 pl-4">PRICE</th>
                            <th className="text-base font-medium leading-4 text-gray-600 pl-5 ">MORE OPTIONS</th>
                            <th className="text-base font-medium leading-4 text-gray-600 2xl:pl-28 2xl:pr-20 pr-4 lg:pr-10" />
                        </tr>
                    </thead>
                    <tbody className="w-full text-left">
                        {
                            fav_items.map((product) =>{
                                const shortenedText = product.product_description.length > 100 ? product.product_description.substring(0, 100) + '...' : product.product_description
                                return (
                                 <tr className="border-gray-200 border-b  ">
                                <th>
                                    <img className="my-10 pl-4" src={product.image_name} alt="shoe" width={"100px"} height={"100px"} />
                                </th>
                                <th className="mt-10 text-base font-medium leading-4 text-gray-600 pl-6">
                                    <p className=" text-base leading-4 text-gray-800">{shortenedText}</p>
                                </th>
                                <th className="my-10  pl-6">
                                    <p className>${product.product_price}</p>
                                </th>
                                <th className="my-10 text-base font-medium leading-4 text-gray-600 pl-6">
                                    <a href={`/products/${product.id}`} className="hover:underline text-base font-medium leading-none  text-gray-800 focus:outline-none focus:underline">
                                        View details
                                    </a>
                                </th>
                                <th className="my-10 pl-4 lg:pl-12">
                                    <button className="focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-800 text-base leading-none text-red-600 hover:text-red-800">
                                        <p onClick={ () => handleRemoveItem(product.id)}> <i class="icon-remove"></i>Remove Item</p>
                                    </button>
                                </th>
                            </tr>
                                )
                            })
                        }
                        
                    </tbody>
                </table>
            </div>
        </div>
        </Layout>
    );
}

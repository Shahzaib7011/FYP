import React from "react";
import Layout from "../../components/layout/Layout";

const Product = () => {
    return (
    <Layout>

    </Layout>
    )
}


export default Product
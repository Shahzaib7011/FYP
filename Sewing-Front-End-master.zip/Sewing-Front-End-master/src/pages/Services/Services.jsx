import React from "react";
import Layout from "../../components/layout/Layout";
import ServiceSection from "../../components/ServiceSection/ServiceSection";


const Services = () => {
    return (
        <Layout>
            <ServiceSection/>
        </Layout>
    )
}

export default Services;
import React, { useState } from "react";
import Layout from "../../components/layout/Layout";
import  MainLogo from "../../assets/images/logo.jpg";
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from "react-redux";
import { addUserInfo } from "../../store/userSlice";
import { RotatingLines } from "react-loader-spinner";
import URLS from '../../config/urls';


import { AxiosProvider, Request, Get, Delete, Head, Post, Put, Patch, withAxios } from 'react-axios'



const SignIn = () => {

    function Loader() {
    return (
        <div className="flex justify-center  p-10 custom_bg_color ">
        <RotatingLines
        strokeColor="grey"
        strokeWidth="5"
        animationDuration="0.75"
        width="96"
        className="justify-center"
        visible={true}
        />
        </div>
    )
    }

    const dispatch = useDispatch();

    const [email, setemail] = useState();
    const [password, setpassword] = useState();
    const [isToastOpen, setIsToastOpen] = useState(false);
    const [isDataLoading, setIsDataLoading] = useState(false);

    const handleToastClose = () => {
        setIsToastOpen(false);
        window.location.href = '/';
    };
    

const handleSubmit = async (e) => {
    setIsDataLoading(true);
    e.preventDefault();
    if (!email || !password) {
        toast('Please fill up all fields');
        return;
    }

    try {
        const response = await fetch(`${URLS.USER_LOGIN_IN_URL}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: email, password: password }),
        });    
        const data = await response.json();
        if (response.status === 401) {
            toast(response.statusText);
            setIsDataLoading(false);
        } else if (response.status === 200) {
            localStorage.setItem(
                'chat-app-current-user',
                JSON.stringify(data.user)
              );
            dispatch(addUserInfo(data.user));
            toast("Welcome Back You will be redirected soon", {
                onClose: handleToastClose
            });
            setIsToastOpen(true);
            setIsDataLoading(false);
        }
    } catch (error) {
        toast(error.message);
    }
};

    return (
    <Layout>
        {isDataLoading ? <Loader /> :
            <section className="bg-gray-50 dark:bg-gray-900 custom_bg_color">
            <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
            <a href="/" className="flex items-center mb-6 text-2xl font-semibold text-gray-900 dark:text-white custom_text_color">
                <img className="w-8 h-8 mr-2" src={MainLogo} alt="logo"/>
                Sui Dhagha
            </a>
            <div className="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                    <h1 className="text-xl font-bold leading-tight tracking-tight custom_text_color">
                        Sign in to your account
                    </h1>
                    <form className="space-y-4 md:space-y-6" action="#">
                        <div>
                            <label htmlFor="email" className="block mb-2 text-sm font-medium custom_text_color">Your email</label>
                            <input type="email" value={email} onChange={ (e) => setemail(e.target.value)} name="email" id="email" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="name@company.com" required=""/>
                        </div>
                        <div>
                            <label htmlFor="password" className="block mb-2 text-sm font-medium custom_text_color">Password</label>
                            <input type="password" value={password} onChange={ (e) => setpassword(e.target.value)} name="password" id="password" placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required=""/>
                        </div>
                        <div className="flex items-center justify-between">
                            <a href="/forgot_password" className="text-sm font-medium text-primary-600 hover:underline dark:text-primary-500 custom_text_color">Forgot password?</a>
                        </div>
                        <div className="flex flex-col items-center">
                            <div className="flex items-center h-5"></div>
                            <button type="button" onClick={handleSubmit} className=" items-center text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700 ">Sign in</button>
                        </div>     
                        <p className="text-sm font-light text-gray-500 dark:text-gray-400 custom_text_color">
                            Don’t have an account yet? <a href="/sign_up" className="font-medium text-primary-600 hover:underline dark:text-primary-500">Sign up</a>
                        </p>
                    </form>
                </div>
            </div>
            </div>
            </section>
        }
    </Layout>
    )

}

export default SignIn
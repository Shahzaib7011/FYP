import React, { useState } from "react";
import Layout from "../../components/layout/Layout";
import  MainLogo from "../../assets/images/logo.jpg";
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from "react-redux";
import { resetUserInfo } from "../../store/userSlice";

import { AxiosProvider, Request, Get, Delete, Head, Post, Put, Patch, withAxios } from 'react-axios'



const ChangePassword = () => {

    const dispatch = useDispatch();

    const [oldPassword, setOldPassword] = useState();
    const [newPassword, setNewPassword] = useState();
    const [repeatNewPassword, setNepeatNewPassword] = useState(false);

    const handleToastClose = () => {
        setIsToastOpen(false);
        window.location.href = '/sign_in';
    };

    const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newPassword || !repeatNewPassword || !oldPassword) {
        toast('Please fill up all fields');
        return;
    }

    if ( newPassword == repeatNewPassword ) {
        toast("Password does n't match");
        return;
    }

    try {
        const response = await fetch('http://44.217.212.115:3002/user/change_password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ oldPassword: oldPassword, newPassword: newPassword, repeatNewPassword: repeatNewPassword }),
        });

        const data = await response.json();
        if (response.status === 401) {
            toast(response.statusText);
        } else if (response.status === 200) {
            dispatch(resetUserInfo());
            toast("Password Reset Successfully", {
                onClose: handleToastClose
            });
            setIsToastOpen(true);
        }
    } catch (error) {
        toast(error.message);
    }
};

    return (
    <Layout>
        <section className="bg-gray-50 dark:bg-gray-900 custom_bg_color">
         <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
        <a href="/" className="flex items-center mb-6 text-2xl font-semibold text-gray-900 dark:text-white custom_text_color">
            <img className="w-8 h-8 mr-2" src={MainLogo} alt="logo"/>
            Sui Dhagha
        </a>
        <div className="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
            <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                <h1 className="text-xl font-bold leading-tight tracking-tight custom_text_color">
                  Change Password
                </h1>
                <form className="space-y-4 md:space-y-6" action="#">
                    <div>
                        <label htmlFor="oldPassword" className="block mb-2 text-sm font-medium custom_text_color">Your Old Password</label>
                        <input type="password" value={email} onChange={ (e) => setemail(e.target.value)} placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required=""/>
                    </div>
                    <div>
                        <label htmlFor="password" className="block mb-2 text-sm font-medium custom_text_color">Your new Password</label>
                        <input type="password" value={password} onChange={ (e) => setpassword(e.target.value)}  placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required=""/>
                    </div>
                   <div>
                        <label htmlFor="password" className="block mb-2 text-sm font-medium custom_text_color">Repeat: Your new Password</label>
                        <input type="password" value={password} onChange={ (e) => setpassword(e.target.value)} placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required=""/>
                    </div>
                    <div className="flex flex-col items-center">
                          <div className="flex items-center h-5"></div>
                          <button type="button" onClick={handleSubmit} className=" items-center text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700 ">Change Password</button>
                     </div>     
                </form>
            </div>
        </div>
         </div>
        </section>
    </Layout>
    )

}

export default ChangePassword
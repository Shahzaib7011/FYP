import React, { useState, useEffect } from "react";
import Layout from "../../components/layout/Layout";
import  MainLogo from "../../assets/images/logo.jpg";
import { toast } from 'react-toastify';
import { getLocation } from 'current-location-geo';
import URLS from '../../config/urls';

const SignUp = () => {
    const [latitude, setLatitude] = useState();
    const [longitude, setLongitude] = useState();
    const [address, setAddress] = useState();
    const [email, setemail] = useState();
    const [password, setpassword] = useState();
    const [username, setusername] = useState();
    const [confirmpassword, setconfirmpassword] = useState();
    const [experience, setexperience] = useState();
    const [phonenumber, setphonenumber] = useState();
    const [accept, setaccept] = useState();
    const [firstName, setfirstname] = useState();
    const [lastName, setlastname] = useState();
    const [isToastOpen, setIsToastOpen] = useState(false);

    useEffect(() => {
        getLocation(function (err, position) {
            if (err) {
                console.error('Error:', err);
            } else {
                setLatitude(position.latitude)
                setLongitude(position.longitude);
                setAddress(position.address);
            }
        });
    });

    const handleToastClose = () => {
        setIsToastOpen(false);
        window.location.href = '/sign_in';
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if( email && firstName && lastName && phonenumber && username && password && confirmpassword && experience) {
            if(password == confirmpassword) {
                const axios = require('axios');
                const qs = require('qs');
                let data = qs.stringify({
                'email': email,
                'firstName': firstName,
                'lastName': lastName,
                'phone': phonenumber,
                'username': username,
                'password': password,
                'confirmpassword': confirmpassword,
                'experience': experience,
                'role': 'tailor',
                'latitude': latitude,
                'longitude': longitude,
                'address': address
                });

                let config = {
                method: 'post',
                maxBodyLength: Infinity,
                url: `${URLS.USER_SIGN_UP}`,
                headers: { 
                    'Content-Type': 'application/x-www-form-urlencoded', 
                    'Cookie': 'connect.sid=s%3A5PO6fcslXPrMEQO4kbFoMlx_ywXSpPyQ.TPgaSI%2FE59pGqBspybSbh6RTWfVPjACj6fhwOIQP6qo'
                },
                data : data
                };
              await axios.request(config)
                .then((response) => {
                    if(response.status == '200') {
                        toast("User registered successfully!",{
                            onClose: handleToastClose
                        });
                        setIsToastOpen(true);
                    }
                })
                .catch((error) => {
                    toast(error);
                });
        }
        else
        {
            toast("Password does n't match");
        }
    }
    else
    {
            toast("Please fill up all fields correctly!");   
    }
        setemail('');
        setpassword('');
        setphonenumber('');
        setconfirmpassword('');
        setexperience('');
        setfirstname('');
        setusername('');
        setlastname('');
    }

    return (
        <Layout>
        <div className="h-auto">
            <section className="bg-gray-50 dark:bg-gray-900 custom_bg_color">
                <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
                    <a href="#" className="flex items-center mb-6 text-2xl font-semibold text-gray-900 dark:text-white custom_text_color">
                        <img className="w-8 h-8 mr-2" src={MainLogo} alt="logo" />
                        Sewing Online
                    </a>
                    <div className="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max  xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                        <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                            <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white custom_text_color">
                                Create and account
                            </h1>
                            <form className="space-y-4 md:space-y-6" action="#">
                                 <div>
                                    <label htmlFor="username" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">Username</label>
                                    <input type="text" value={username} onChange={ (e) => setusername(e.target.value)} name="username" id="username" placeholder="e.g Tom" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" />
                                </div>
                                <div className="flex flex-wrap gap-8">
                                    <div className="md:w-1/3">
                                        <label htmlFor="email" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">First Name</label>
                                            <input type="text" value={firstName} onChange={(e) => setfirstname(e.target.value)} name="firstName" id="first_name" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="name@company.com" required="" />
                                    </div>
                                    <div className="md:w-1/3">
                                        <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">Last Namsse</label>
                                            <input type="text" value={lastName} onChange={(e) => setlastname(e.target.value)} name="lastName" id="last_name" placeholder="e,g smith" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" />
                                    </div>
                                </div>
                                <div className="flex flex-wrap gap-8">
                                    <div className="md:w-1/3">
                                        <label htmlFor="email" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">Your email</label>
                                        <input type="email"  value={email} onChange={(e) => setemail(e.target.value)} name="email" id="email" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="name@company.com" required="" />
                                    </div>
                                    <div className="md:w-1/3">
                                        <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">Password</label>
                                        <input type="password" value={password} onChange={(e) => setpassword(e.target.value)} name="password" id="password" placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" />
                                    </div>
                                </div>
                                <div className="flex flex-wrap gap-8">
                                    <div className="md:w-1/3">
                                        <label htmlFor="confirm-password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">Confirm password</label>
                                        <input type="password" value={confirmpassword} onChange={(e) => setconfirmpassword(e.target.value)} name="confirmpassword" id="confirm-password" placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" />
                                    </div>
                                    <div className="md:w-1/3">
                                        <label htmlFor="experience" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">No of Year Expereience </label>
                                        <input type="number" value={experience} onChange={ (e) => { setexperience(e.target.value)}} name="experience" id="experience" placeholder="4" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" />
                                    </div>
                                </div>
                                <div>
                                    <label htmlFor="confirm-password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white custom_text_color">Phone Number</label>
                                    <input type="tel" value={phonenumber} onChange={ (e) => setphonenumber(e.target.value)} name="phone" id="phone" placeholder="+923332456789" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" />
                                </div>
                                <div className="flex items-start">
                                    <div className="flex items-center h-5">
                                        <input id="terms" aria-describedby="terms" value={accept} onChange={ (e) => setaccept(e.target.value)} type="checkbox" className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-primary-600 dark:ring-offset-gray-800" required="" />
                                    </div>
                                    <div className="ml-3 text-sm">
                                        <label htmlFor="terms" className="font-light text-gray-500 dark:text-gray-300">
                                            I accept the
                                            <a className="font-medium text-primary-600 hover:underline dark:text-primary-500" href="#">Terms and Conditions</a>
                                        </label>
                                    </div>
                                </div>
                                 <div className="flex flex-col items-center">
                                    <div className="flex items-center h-5"></div>
                                    <button type="button" onClick={handleSubmit} className="items-center text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">
                                        Create an account
                                    </button>
                                </div>
                                <p className="text-sm font-light text-gray-500 dark:text-gray-400">
                                    Already have an account? 
                                    <a href="/sign_in" className="font-medium text-primary-600 hover:underline dark:text-primary-500">Login here</a>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
                </section>
            </div>
         </Layout>
    )

}

export default SignUp
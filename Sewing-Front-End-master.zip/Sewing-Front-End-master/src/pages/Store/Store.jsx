import React,  { useEffect, useState } from 'react';
import Layout from "../../components/layout/Layout";
import BannerSection from "../../components/BannerSection/BannerSection";
import ProductCart from "../../components/productCart/ProductCart";
import SearchBar from "../../components/SearchBar/SearchBar";
import HeadingSection from "../../components/HeadingSection/HeadingSection";
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from "react-redux";
import { additem } from "../../store/cartSlice";
import { addToFavour } from '../../store/favouriteSlice';
import { getProductAsyc } from '../../store/productSlice';



const Store = () => {
  const dispatch = useDispatch();


    useEffect(() => {
      dispatch(getProductAsyc())
    },[])

    const { products } = useSelector((state) => state.products);  
    const { email } = useSelector((state) => state.users); 
     const handleadditem = (key, image_name, product_name, product_description, product_price) => {
      if(!email)
      {
        toast("Login first Before adding the product in cart", { type: "failure" });
        return;
      }
      dispatch(additem({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Cart", { type: "success" });
    }

    const handlefavItem = (key, image_name, product_name, product_description, product_price) => {
      if(!email)
      {
        toast("Login first Before adding into favourites", { type: "failure" });
        return;
      }
      dispatch(addToFavour({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Favourite", { type: "success" });
    }

    return (
        <Layout>
            <SearchBar/>
            <HeadingSection heading_name="All Products with Export Quality" classNam="mt-3 mb-3"/>
            <BannerSection/>
            <div className='grid sm:grid-cols-3 grid-cols-1'>
            {
              products.map((product) =>{
                const shortenedText = product.description.length > 100 ? product.description.substring(0, 100) + '...' : product.description
                return (
                  <div className='product-item' key={product._id}>
                   <ProductCart product_id={product._id} image_name={product.image_url} product_name={product.title} product_description={shortenedText} product_price={product.list_price.$numberDecimal} handleadditem={handleadditem}  handlefavItem={handlefavItem}/>
                  </div>
                )
              })
            }
            </div>
        </Layout>

    )
}

export default Store;
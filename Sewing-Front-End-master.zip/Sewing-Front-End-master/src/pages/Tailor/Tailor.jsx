import React,  { useEffect, useState } from 'react';
import Layout from "../../components/layout/Layout";
import TailerProfileCard from "../../components/TailerProfileCard/TailerProfileCard";
import SearchBar from "../../components/SearchBar/SearchBar";

import { useSelector, useDispatch } from "react-redux";
import { addTailors  } from "../../store/tailorSlice";
import { getTailorsAsync } from '../../store/tailorSlice';


const Tailor = () => {

   const dispatch = useDispatch();
 
  useEffect(() => {
    dispatch(getTailorsAsync())
  },[])


  const { tailors } = useSelector((state) => state.tailors);
  const { firstName, lastName, userName, email, phone_number,  image, expereince, login} = useSelector((state) => state.users);
    return (
        <Layout>
          <SearchBar/>
          <div className="grid sm:grid-cols-3 grid-cols-1">
            {
                tailors.map((tailor) =>{
                  return (             
                     <TailerProfileCard id={tailor._id} username={tailor.username} image_url={tailor.image_url} email={tailor.email} lastName={tailor.lastName} firstName={tailor.firstName}  phone={tailor.phone} created_at={tailor.created_at} experience={tailor.experience} login={login} admin_email={email} admin_username={userName} />
                  )
                })
            }
          </div>
        </Layout>
    )
}

export default Tailor
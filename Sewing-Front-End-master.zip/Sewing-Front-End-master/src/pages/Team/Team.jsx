import React,  { useEffect, useState } from 'react';
import Layout from "../../components/layout/Layout";
import BannerSection from "../../components/BannerSection/BannerSection";
import ProductCart from "../../components/productCart/ProductCart";
import FeatureTeamSection from "../../components/FeatureSection/FeatureTeamSection";

import { useSelector, useDispatch } from "react-redux";
import { addProduct, addTeam  } from "../../store/teamSlice";
import { additem } from "../../store/cartSlice";
import { addToFavour } from '../../store/favouriteSlice';
import { getTeamsAsync } from '../../store/teamSlice';
import { toast } from 'react-toastify';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

const Team = () => {
  const dispatch = useDispatch();
  const { email } = useSelector((state) => state.users); 
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 5
    },
    desktop: {
      breakpoint: { max: 8000, min: 1024 },
      items: 5
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };

 
  useEffect(() => {
    dispatch(getTeamsAsync())
  },[])

    const handleadditem = (key, image_name, product_name, product_description, product_price) => {
      if(!email){
        toast("Login first Before adding the product in cart", { type: "failure" });
        return;
      }
      dispatch(additem({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Cart", { type: "success" });
    }

    const handlefavItem = (key, image_name, product_name, product_description, product_price) => {
      if(!email)
      {
        toast("Login first Before adding into favourites", { type: "failure" });
        return;
      }
      dispatch(addToFavour({ id: key, image_name: image_name, product_name: product_name, product_description: product_description, product_price: product_price, quantity: 1 }))
      toast("Item Added To Favourite", { type: "success" });
    }


  const { teams, products } = useSelector((state) => state.teams);
    return(
        <Layout>
            <FeatureTeamSection teams={teams} />
            <BannerSection section_name={"Explore Products"} section_category={"See More Products"}/>
            {
              // <div className="flex py-12 px-4 gap-3 custom_bg_color">
               <Carousel responsive={responsive}>
                {
                  products.map((product) =>{
                    const shortenedText = product.description.length > 100 ? product.description.substring(0, 100) + '...' : product.description
                    return (
                      <ProductCart product_id={product._id} image_name={product.image_url} product_name={product.title} product_description={shortenedText} product_price={product.list_price.$numberDecimal} handleadditem={handleadditem}  handlefavItem={handlefavItem}/>
                    )
                  })
                }
                </Carousel>
            }
            
        </Layout>
    )

}

export default Team;
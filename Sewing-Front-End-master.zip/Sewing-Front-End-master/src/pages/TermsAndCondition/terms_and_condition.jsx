import React from "react";
import Layout from "../../components/layout/Layout";


const TermsAndCondition = () => {
    return (
    <Layout>
          <div className="container mx-auto p-4 custom_bg_color">
        <h1 className="text-3xl font-bold mb-4">Terms and Conditions</h1>
        <ol className="list-decimal list-inside">
            <li className="mb-2"> <strong>Acceptance of Terms:</strong> By accessing or using the Sui Dhaga platform
                ("Platform"), you agree to comply with and be bound by these Terms and Conditions ("Terms"). If you do
                not agree to these Terms, you may not access or use the Platform.</li>
            <li className="mb-2"> <strong>Use of Platform:</strong> The Platform serves as a marketplace connecting
                clients with tailors for tailoring services. Users are solely responsible for their interactions and
                transactions conducted on the Platform. Sui Dhaga does not assume any liability for the quality of
                services provided by tailors.</li>
            <li className="mb-2"> <strong>User Accounts:</strong> Users may be required to create an account to access
                certain features of the Platform. Users are responsible for maintaining the confidentiality of their
                account credentials and for all activities that occur under their account.</li>
            <li className="mb-2"> <strong>Intellectual Property:</strong> All content and materials on the Platform,
                including but not limited to text, graphics, logos, images, and software, are the property of Sui Dhaga
                or its licensors and are protected by copyright and other intellectual property laws.</li>
            <li className="mb-2"> <strong>User Content:</strong> By submitting content to the Platform (e.g., reviews,
                feedback), users grant Sui Dhaga a non-exclusive, royalty-free, perpetual, irrevocable, and fully
                sublicensable right to use, reproduce, modify, adapt, publish, translate, distribute, and display such
                content worldwide.</li>
            <li className="mb-2"> <strong>Prohibited Conduct:</strong> Users agree not to engage in any conduct that
                violates these Terms or infringes upon the rights of others. Prohibited conduct includes but is not
                limited to: (a) using the Platform for unlawful purposes, (b) impersonating another person or entity,
                (c) interfering with the operation of the Platform, and (d) uploading malicious code or viruses.</li>
            <li className="mb-2"> <strong>Privacy Policy:</strong> Sui Dhaga's Privacy Policy governs the collection, use,
                and disclosure of users' personal information. By using the Platform, users consent to the collection
                and use of their personal information in accordance with the Privacy Policy.</li>
            <li className="mb-2"> <strong>Limitation of Liability:</strong> Sui Dhaga shall not be liable for any indirect,
                incidental, special, consequential, or punitive damages arising out of or related to the use of the
                Platform or any services provided therein.</li>
            <li className="mb-2"> <strong>Governing Law:</strong> These Terms shall be governed by and construed in
                accordance with the laws of [Jurisdiction], without regard to its conflict of law provisions.</li>
            <li className="mb-2"> <strong>Changes to Terms:</strong> Sui Dhaga reserves the right to modify or revise these
                Terms at any time without prior notice. Continued use of the Platform after any such changes shall
                constitute your acceptance of the revised Terms.</li>
        </ol>
        <p className="mt-4">By accessing or using the Platform, you acknowledge that you have read, understood, and agree
            to be bound by these Terms and Conditions.</p>
    </div>
    </Layout>
    )
}


export default TermsAndCondition
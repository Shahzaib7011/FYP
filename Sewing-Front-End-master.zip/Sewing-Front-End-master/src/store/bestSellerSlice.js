import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getBestSellerAsyc = createAsyncThunk('products/getBestSellerAsyc', async() => {
  try {  
  const response = await fetch(`${URLS.BEST_SELLER_URL}`)
    if(response.ok)
    {
        const products = await response.json();
        return {products}
    }
    else{
      console.log("Failed to get product")
    }
  }

  catch(err) {
    console.error(err)

  }
})


const bestSellerSlice = createSlice({
      name: "products",
      initialState: {
        best_seller_products: []
      },

  extraReducers: builder => {
    builder
      .addCase(getBestSellerAsyc.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getBestSellerAsyc.fulfilled, (state, action) => {
        state.best_seller_products = action.payload.products;
      });
    }
})
export default bestSellerSlice.reducer;


    

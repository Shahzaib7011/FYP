import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

const calculateSubTotal = (cart_items) => {
  return cart_items.reduce((total, item) => total + item.product_price * item.quantity, 0);
};

const calculateTotal = (sub_total, tax, delivery_amount) => {
  return sub_total + tax + delivery_amount;
};

const calculateDeliveryAmount = () => {
  return 30
}

const calculateTaxTotal = (total) => {
  return (16/100 * total)
};

export const getCartAsync = createAsyncThunk('home/getCartAsync', async() => {
    const user = JSON.parse(localStorage.getItem('chat-app-current-user'));
    const response = await fetch(`${ORDER_SUMMARY_URL}?user_id=${user._id}`)  
    if(response.ok)
    {
        const order_summaries = await response.json();
        console.log(order_summaries);
        return order_summaries;
    }
})

const cartSlice = createSlice({
  name: "carts",
  initialState: {
    order_summaries: [],
    cart_items: [],
    total: 0,
    sub_total: 0,
    tax: 0,
    delivery_amount: 0,
    address: {
      street: '',
      country: '',
      city: '',
      phone_number: '',
      zip_code: '',
    },
    payment_method: {
      cod: false,
      bank_transfer: false,
      credit_card: false,
    },
    payment_status: false

  },
  reducers: {
    additem: (state, action) => {
      const existingItemIndex = state.cart_items.findIndex(item => item.id === action.payload.id);

      if (existingItemIndex !== -1) {
          // If the item exists, increase its quantity
          state.cart_items[existingItemIndex].quantity += 1;
      } else {
          // If the item doesn't exist, add it as a new item
          const newItem = {
              id: action.payload.id, 
              image_name: action.payload.image_name,
              product_name: action.payload.product_name,
              product_description: action.payload.product_description,
              product_price: action.payload.product_price,
              quantity: 1 
          };
          state.cart_items.push(newItem);
      }
      state.sub_total = calculateSubTotal(state.cart_items);
      state.tax = calculateTaxTotal(state.total);
      state.total = calculateTotal(state.sub_total, state.tax, state.delivery_amount);
    },
    deleteitem: (state, action) => {
      state.cart_items = state.cart_items.filter(product => product.id !== action.payload);
      if(state.cart_items.length > 0) {
        state.sub_total = calculateSubTotal(state.cart_items);
      state.tax = calculateTaxTotal(state.total);
      state.total = calculateTotal(state.sub_total, state.tax, state.delivery_amount);
      state.delivery_amount = calculateDeliveryAmount()
      }
      else
      {
        state.cart_items = [];
        state.tax = 0;
        state.total = 0;
        state.delivery_amount = 0;
        state.sub_total = 0;

      }
      
    },
    increasequantity: (state, action) => {
      state.cart_items = state.cart_items.map(product => {
        if (product.id === action.payload) {
          return {
            ...product,
            quantity: product.quantity + 1
          };
        }
        // If the IDs don't match, return the original product object unchanged
        return product;
      });
      state.sub_total = calculateSubTotal(state.cart_items);
      state.tax = calculateTaxTotal(state.total);
      state.total = calculateTotal(state.sub_total, state.tax, state.delivery_amount);
      state.delivery_amount = calculateDeliveryAmount()
    },
    decreasequantity: (state, action) => {
      let temp_quantity = 0;
      let new_quantity = 0;
      state.cart_items = state.cart_items.map(product => {
        let temp_quantity = product.quantity 
        if (product.id === action.payload) {
          return {
            ...product,
            quantity: Math.max(1, product.quantity - 1),
          };
          new_quantity = Math.max(1, product.quantity - 1);
        }
        return product;
      });
      state.sub_total = calculateSubTotal(state.cart_items);
      state.tax = calculateTaxTotal(state.total);
      state.total = calculateTotal(state.sub_total, state.tax, state.delivery_amount);
      state.delivery_amount = calculateDeliveryAmount()
    },
    clearCart: (state, action) => {
      state.cart_items = [];
      state.tax = 0;
      state.total = 0;
      state.delivery_amount = 0;
      state.sub_total = 0;
    },
    addAddress: (state, action) => {
      console.log(state)
    }
  },
    extraReducers: builder => {
    builder
      .addCase(getCartAsync.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getCartAsync.fulfilled, (state, action) => {
        state.order_summaries = action.payload;
      });
    }
});


export const { additem, deleteitem, increasequantity, decreasequantity, clearCart, addAddress } = cartSlice.actions;
export default cartSlice.reducer;
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getCategorySync = createAsyncThunk('categories/getCategorySync', async() => {
  try {  
  const response = await fetch(`${URLS.CATEGORY_URL}`);
    if(response.ok)
    {
        const category = await response.json();
        return {category}
    }
    else{
      console.log("Failed to get product")
    }
  }

  catch(err) {
    console.error(err)

  }
})

export const getSpecificCategorySync = createAsyncThunk('categories/getSpecificCategorySync', async(id) => {
  try {  
  const response = await fetch(`${URLS.SPECIFIC_CATEGORY_URL}/${id}`)
    if(response.ok)
    {
        const specific_category = await response.json();
        return {specific_category}
    }
    else{
      console.log("Failed to get product")
    }
  }

  catch(err) {
    console.error(err)

  }

})


const categorySlice = createSlice({
      name: "categories",
      initialState: {
        category: [],
        specific_category: [],
        specific_category_list: []
      },

  extraReducers: builder => {
    builder
      .addCase(getCategorySync.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getCategorySync.fulfilled, (state, action) => {
        state.category = action.payload.category.categories;
      })
      .addCase(getSpecificCategorySync.pending, (state, action) => {
         console.log("Data is Pending");
      })
      .addCase(getSpecificCategorySync.fulfilled, (state, action) => {
        state.specific_category = action.payload.specific_category.category;
        state.specific_category_list =action.payload.specific_category.products;
      });
    }
})
export default categorySlice.reducer;


    

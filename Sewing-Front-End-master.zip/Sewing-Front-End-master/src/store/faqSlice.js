import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getFaqAsyc = createAsyncThunk('faqs/getfaqsasync', async() => {
    const response = await fetch(`${URLS.FAQ_URL}`)
    if(response.ok)
    {
        const faqs_list = await response.json();
        return faqs_list;
    }
})

const faqSlice = createSlice({
  name: "faqs",
  initialState: [],
  reducers: {
    addFaq: (state, action) => {
      const newFaq = {
        id: action.payload.id,
        question: action.payload.question,
        tag_line: action.payload.tag_line,
        answer: action.payload.answer,
        completed: false,
      };
      state.push(newFaq);
    },
    toggleFaqComplete: (state, action) => {
      const index = state.findIndex((faq) => faq.id === action.payload.id);
      if (index) {
        state[index].completed = action.payload.completed;
      }
    },
    deleteFaq: (state, action) => {
       return state.filter((todo) => todo.id !== action.payload.id)
    },
  },
  extraReducers: builder => {
    builder
      .addCase(getFaqAsyc.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getFaqAsyc.fulfilled, (state, action) => {
         return action.payload;
      });
    }
});
export const { addFaq, toggleFaqComplete, deleteFaq } = faqSlice.actions;
export default faqSlice.reducer;
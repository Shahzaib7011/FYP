import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";


const favSlice = createSlice({
  name: "favourites",
  initialState: {
    fav_items: []
  },
  reducers: {
    addToFavour: (state, action) => {
      const newItem = {
         id: action.payload.id, 
         image_name: action.payload.image_name,
          product_name: action.payload.product_name,
          product_description: action.payload.product_description,
          product_price: action.payload.product_price
      };
      state.fav_items.push(newItem);
    },
    clearFavourite: (state, action) => {
      state.fav_items = [];
    },
    removeToFavour: (state, action) => {
      state.fav_items = state.fav_items.filter(product => product.id !== action.payload);
    }
   }
});
export const { addToFavour, removeToFavour,  clearFavourite } = favSlice.actions;
export default favSlice.reducer;
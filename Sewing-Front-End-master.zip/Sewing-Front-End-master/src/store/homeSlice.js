import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getHomeAsync = createAsyncThunk('home/getHomeAsync', async() => {
    const response = await fetch(`${URLS.HOME_URL}`)
    if(response.ok)
    {
        const home_items = await response.json();
        return home_items;
    }
})

const homeSlice = createSlice({
  name: "home",
  initialState: {
    ProductimageUrls: [],
    products: [],
    tailors: [],
    tailorsUrls: [],
    testimonials: []
  },
  reducers: {
      addProduct: (state, action) => {
      const newProduct = {
        id: action.payload.id,
        title: action.payload.title,
        image_url: action.payload.image_url,
        description: action.payload.description,
        list_price: action.payload.list_price
      };
      state.products.push(newProduct);
    }

  },
  extraReducers: builder => {
    builder
      .addCase(getHomeAsync.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getHomeAsync.fulfilled, (state, action) => {
        state.products = action.payload.product;
        state.tailors = action.payload.tailors;
        state.ProductimageUrls = action.payload.ProductimageUrls;
        state.tailorsUrls = action.payload.tailorsUrls;
        state.testimonials = action.payload.testimonials;
      });
    }
});

export const { addProduct } = homeSlice.actions;
export default homeSlice.reducer;

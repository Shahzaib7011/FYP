import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getProductAsyc = createAsyncThunk('products/getproductsasync', async() => {
  try {  
  const response = await fetch(`${URLS.PRODUCT_URL}`)
    if(response.ok)
    {
        const products = await response.json();
        return {products}
    }
    else{
      console.log("Failed to get product")
    }
  }

  catch(err) {
    console.error(err)

  }
})


const productSlice = createSlice({
      name: "products",
      initialState: {
        products: []
      },

  extraReducers: builder => {
    builder
      .addCase(getProductAsyc.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getProductAsyc.fulfilled, (state, action) => {
        state.products = action.payload.products;
      });
    }
})
export default productSlice.reducer;


    

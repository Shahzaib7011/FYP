import { configureStore } from '@reduxjs/toolkit';
import { persistReducer, persistStore } from 'redux-persist';
import { FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from 'redux-persist/es/constants';

import productSlice from './productSlice';
import faqSlice from './faqSlice';
import teamSlice from './teamSlice';
import tailorSlice from './tailorSlice';
import homeSlice from './homeSlice';
import cartSlice from './cartSlice';
import favouriteSlice from './favouriteSlice';
import bestSellerSlice from './bestSellerSlice';
import userSlice from './userSlice';
import categorySlice from './categorySlice';
import persistConfig from '../persistConfig';

const persistedCartReducer = persistReducer(persistConfig, cartSlice);
const persistFavouriteReducer = persistReducer(persistConfig, favouriteSlice);
const persistUserReducer = persistReducer(persistConfig, userSlice);
const persistProductReducer = persistReducer(persistConfig, productSlice);
const persistTeamReducer = persistReducer(persistConfig, teamSlice);

const store = configureStore({
  reducer: {
    products: persistProductReducer,
    faqs: faqSlice,
    teams: persistTeamReducer,
    tailors: tailorSlice,
    home: homeSlice,
    carts: persistedCartReducer,
    favourites: persistFavouriteReducer,
    best_seller: bestSellerSlice,
    users: persistUserReducer,
    category: categorySlice,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});

export const persistor = persistStore(store);
export default store;

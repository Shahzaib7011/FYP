import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getTailorsAsync = createAsyncThunk('teams/gettailorsasync', async() => {
    const response = await fetch(`${URLS.TAILOR_URL}`)
    if(response.ok)
    {
        const tailors_list = await response.json();
        return tailors_list;
    }
})



const tailorSlice = createSlice({
  name: "tailors",
  initialState: {
    tailors: []
  },
  reducers: {
    addTailors: (state, action) => {
      const newTailor = {
        id: action.payload.id,
        image_url: action.payload.image_url,
        firstName: action.payload.firstName,
        lastName: action.payload.lastName,
        phone: action.payload.phone,
        username: action.payload.username
      };
      state.tailors.push(newTailor);
    }
  },
  extraReducers: builder => {
    builder
      .addCase(getTailorsAsync.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getTailorsAsync.fulfilled, (state, action) => {
        state.tailors = action.payload.tailors
      });
    }
});
export const { addTailors } = tailorSlice.actions;
export default tailorSlice.reducer;
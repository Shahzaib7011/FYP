import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import URLS from '../config/urls';

export const getTeamsAsync = createAsyncThunk('teams/getteamsasync', async() => {
    const response = await fetch(`${URLS.TEAM_URL}`, {
        redirect: 'follow' // Allow the browser to automatically follow redirects
    });
    if(response.ok)
    {
        const teams_list = await response.json();
        return teams_list;
    }
})



const teamSlice = createSlice({
  name: "teams",
  initialState: {
    teams: [],
    products: []
  },
  reducers: {
    addTeam: (state, action) => {
      const newTeam = {
            id: action.payload.id,
            name: action.payload.name,
            position: action.payload.position,
            description: action.payload.description,
            image_url: action.payload.image_url,
            phone_number: action.payload.phone_number,
            youtube_handle: action.payload.youtube_handle,
            twitter_handle: action.payload.twitter_handle,
            facebook_handle: action.payload.facebook_handle,
            tiktok_handle: action.payload.tiktok_handle,
      };
      state.teams.push(newTeam);
    },
    addProduct: (state, action) => {
      const newProduct = {
        id: action.payload.id,
        title: action.payload.title,
        image_url: action.payload.image_url,
        description: action.payload.description,
        list_price: action.payload.list_price
      };
      state.products.push(newProduct);
    }
  },
  extraReducers: builder => {
    builder
      .addCase(getTeamsAsync.pending, (state, action) => {
        console.log("Data is Pending");
      })
      .addCase(getTeamsAsync.fulfilled, (state, action) => {
        state.teams = action.payload.teams;
        state.products = action.payload.products;
      });
    }
});
export const { addTeam, addProduct } = teamSlice.actions;
export default teamSlice.reducer;
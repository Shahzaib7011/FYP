import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "users",
  initialState: {
    user_id: '',
    firstName: '',
    lastName: '',
    userName: '',
    email: '',
    phone: '',
    image: '',
    experience: 0,
    description: '',
    login: false,
    role: '',
  },
  reducers: {
    addUserInfo: (state, action) => {
        state.experience = action.payload.experience? action.payload.experience : 0
        state.user_id = action.payload?._id
        state.firstName = action.payload?.firstName;
        state.lastName = action.payload?.lastName;
        state.userName = action.payload?.username;
        state.email = action.payload?.email;
        state.phone = action.payload?.phone;
        state.image = action.payload?.image_url;
        state.role = action.payload?.role;
        state.login = true;
        state.description = action.payload?.description;
    },
    resetUserInfo: (state, action) => {
        state.firstName = '';
        state.lastName = '';
        state.userName = '';
        state.email = '';
        state.phone = '';
        state.user_id = '';
        state.image = '';
        state.login = false;
        state.role = '';
        state.description = '';
    }
  }
});
export const { addUserInfo, resetUserInfo } = userSlice.actions;
export default userSlice.reducer;